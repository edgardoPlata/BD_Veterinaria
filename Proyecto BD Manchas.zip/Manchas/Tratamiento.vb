﻿Public Class Tratamiento

    Private Sub Tratamiento_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'VeterinariaDataSet.Tratamiento' Puede moverla o quitarla según sea necesario.
        Me.TratamientoTableAdapter.Fill(Me.VeterinariaDataSet.Tratamiento)
        limpiarTratamiento()
    End Sub

    Sub limpiarTratamiento()
        CodTratamientoTextBox.Clear()
        TratamientoTextBox.Clear()
        DescripcionTextBox.Clear()
        CostoTextBox.Clear()

    End Sub

    Private Sub AgregarTratamiento_Click(sender As Object, e As EventArgs) Handles AgregarTratamiento.Click
        Me.TratamientoTableAdapter.AgregarTratamiento(CodTratamientoTextBox.Text, TratamientoTextBox.Text, DescripcionTextBox.Text, CostoTextBox.Text)
        Me.TratamientoTableAdapter.Fill(Me.VeterinariaDataSet.Tratamiento)
        limpiarTratamiento()

    End Sub

    Private Sub BuscarTratamiento_Click(sender As Object, e As EventArgs) Handles BuscarTratamiento.Click
        Me.TratamientoTableAdapter.BuscarTratamiento(Me.VeterinariaDataSet.Tratamiento, CodTratamientoTextBox.Text)
    End Sub

    Private Sub ModificarTratamiento_Click(sender As Object, e As EventArgs) Handles ModificarTratamiento.Click
        Me.TratamientoTableAdapter.ModificarTratamiento(CodTratamientoTextBox.Text, TratamientoTextBox.Text, DescripcionTextBox.Text, CostoTextBox.Text)
        Me.TratamientoTableAdapter.Fill(Me.VeterinariaDataSet.Tratamiento)
        limpiarTratamiento()

    End Sub

    Private Sub MostrarTratamiento_Click(sender As Object, e As EventArgs) Handles MostrarTratamiento.Click
        Me.TratamientoTableAdapter.Fill(Me.VeterinariaDataSet.Tratamiento)
        limpiarTratamiento()

    End Sub

    Private Sub EliminarTratamiento_Click(sender As Object, e As EventArgs) Handles EliminarTratamiento.Click
        Me.TratamientoTableAdapter.EliminarTratamiento(CodTratamientoTextBox.Text)
        Me.TratamientoTableAdapter.Fill(Me.VeterinariaDataSet.Tratamiento)
        limpiarTratamiento()

    End Sub

    Private Sub LimpiarTrtamiento_Click(sender As Object, e As EventArgs) Handles LimpiarTrtamiento.Click
        limpiarTratamiento()

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub
End Class