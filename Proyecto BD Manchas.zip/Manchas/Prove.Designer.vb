﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Prove
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim CodProveedorLabel As System.Windows.Forms.Label
        Dim NombreLabel As System.Windows.Forms.Label
        Dim ApellidoLabel As System.Windows.Forms.Label
        Dim DireccionLabel As System.Windows.Forms.Label
        Dim TelefonoLabel As System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CodProveedorTextBox = New System.Windows.Forms.TextBox()
        Me.NombreProveedor = New System.Windows.Forms.TextBox()
        Me.ApellidoProveedor = New System.Windows.Forms.TextBox()
        Me.DireccionProveedor = New System.Windows.Forms.TextBox()
        Me.TelefonoProveedor = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.ProveedorDataGridView = New System.Windows.Forms.DataGridView()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.LlimpiarProveedor = New System.Windows.Forms.Button()
        Me.EliminarProveedor = New System.Windows.Forms.Button()
        Me.ModificarProveedor = New System.Windows.Forms.Button()
        Me.BuscarProveedores = New System.Windows.Forms.Button()
        Me.MostrarProveedores = New System.Windows.Forms.Button()
        Me.AgregarProveedor = New System.Windows.Forms.Button()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProveedorBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VeterinariaDataSet = New Manchas.VeterinariaDataSet()
        Me.ProveedorTableAdapter = New Manchas.VeterinariaDataSetTableAdapters.ProveedorTableAdapter()
        Me.TableAdapterManager = New Manchas.VeterinariaDataSetTableAdapters.TableAdapterManager()
        CodProveedorLabel = New System.Windows.Forms.Label()
        NombreLabel = New System.Windows.Forms.Label()
        ApellidoLabel = New System.Windows.Forms.Label()
        DireccionLabel = New System.Windows.Forms.Label()
        TelefonoLabel = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.ProveedorDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        CType(Me.ProveedorBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VeterinariaDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CodProveedorLabel
        '
        CodProveedorLabel.AutoSize = True
        CodProveedorLabel.Location = New System.Drawing.Point(10, 32)
        CodProveedorLabel.Name = "CodProveedorLabel"
        CodProveedorLabel.Size = New System.Drawing.Size(159, 24)
        CodProveedorLabel.TabIndex = 0
        CodProveedorLabel.Text = "Cod Proveedor:"
        '
        'NombreLabel
        '
        NombreLabel.AutoSize = True
        NombreLabel.Location = New System.Drawing.Point(10, 68)
        NombreLabel.Name = "NombreLabel"
        NombreLabel.Size = New System.Drawing.Size(91, 24)
        NombreLabel.TabIndex = 2
        NombreLabel.Text = "Nombre:"
        '
        'ApellidoLabel
        '
        ApellidoLabel.AutoSize = True
        ApellidoLabel.Location = New System.Drawing.Point(10, 104)
        ApellidoLabel.Name = "ApellidoLabel"
        ApellidoLabel.Size = New System.Drawing.Size(92, 24)
        ApellidoLabel.TabIndex = 4
        ApellidoLabel.Text = "Apellido:"
        '
        'DireccionLabel
        '
        DireccionLabel.AutoSize = True
        DireccionLabel.Location = New System.Drawing.Point(10, 140)
        DireccionLabel.Name = "DireccionLabel"
        DireccionLabel.Size = New System.Drawing.Size(106, 24)
        DireccionLabel.TabIndex = 6
        DireccionLabel.Text = "Direccion:"
        '
        'TelefonoLabel
        '
        TelefonoLabel.AutoSize = True
        TelefonoLabel.Location = New System.Drawing.Point(10, 176)
        TelefonoLabel.Name = "TelefonoLabel"
        TelefonoLabel.Size = New System.Drawing.Size(99, 24)
        TelefonoLabel.TabIndex = 8
        TelefonoLabel.Text = "Telefono:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(CodProveedorLabel)
        Me.GroupBox1.Controls.Add(Me.CodProveedorTextBox)
        Me.GroupBox1.Controls.Add(NombreLabel)
        Me.GroupBox1.Controls.Add(Me.NombreProveedor)
        Me.GroupBox1.Controls.Add(ApellidoLabel)
        Me.GroupBox1.Controls.Add(Me.ApellidoProveedor)
        Me.GroupBox1.Controls.Add(DireccionLabel)
        Me.GroupBox1.Controls.Add(Me.DireccionProveedor)
        Me.GroupBox1.Controls.Add(TelefonoLabel)
        Me.GroupBox1.Controls.Add(Me.TelefonoProveedor)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 13)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(378, 206)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Proveedores"
        '
        'CodProveedorTextBox
        '
        Me.CodProveedorTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ProveedorBindingSource, "CodProveedor", True))
        Me.CodProveedorTextBox.Location = New System.Drawing.Point(185, 29)
        Me.CodProveedorTextBox.Name = "CodProveedorTextBox"
        Me.CodProveedorTextBox.Size = New System.Drawing.Size(187, 30)
        Me.CodProveedorTextBox.TabIndex = 1
        '
        'NombreProveedor
        '
        Me.NombreProveedor.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ProveedorBindingSource, "Nombre", True))
        Me.NombreProveedor.Location = New System.Drawing.Point(185, 65)
        Me.NombreProveedor.Name = "NombreProveedor"
        Me.NombreProveedor.Size = New System.Drawing.Size(187, 30)
        Me.NombreProveedor.TabIndex = 3
        '
        'ApellidoProveedor
        '
        Me.ApellidoProveedor.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ProveedorBindingSource, "Apellido", True))
        Me.ApellidoProveedor.Location = New System.Drawing.Point(185, 101)
        Me.ApellidoProveedor.Name = "ApellidoProveedor"
        Me.ApellidoProveedor.Size = New System.Drawing.Size(187, 30)
        Me.ApellidoProveedor.TabIndex = 5
        '
        'DireccionProveedor
        '
        Me.DireccionProveedor.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ProveedorBindingSource, "Direccion", True))
        Me.DireccionProveedor.Location = New System.Drawing.Point(185, 137)
        Me.DireccionProveedor.Name = "DireccionProveedor"
        Me.DireccionProveedor.Size = New System.Drawing.Size(187, 30)
        Me.DireccionProveedor.TabIndex = 7
        '
        'TelefonoProveedor
        '
        Me.TelefonoProveedor.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ProveedorBindingSource, "Telefono", True))
        Me.TelefonoProveedor.Location = New System.Drawing.Point(185, 173)
        Me.TelefonoProveedor.Name = "TelefonoProveedor"
        Me.TelefonoProveedor.Size = New System.Drawing.Size(187, 30)
        Me.TelefonoProveedor.TabIndex = 9
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.ProveedorDataGridView)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(396, 13)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(770, 357)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Datos Proveedores"
        '
        'ProveedorDataGridView
        '
        Me.ProveedorDataGridView.AutoGenerateColumns = False
        Me.ProveedorDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ProveedorDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5})
        Me.ProveedorDataGridView.DataSource = Me.ProveedorBindingSource
        Me.ProveedorDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ProveedorDataGridView.Location = New System.Drawing.Point(3, 26)
        Me.ProveedorDataGridView.Name = "ProveedorDataGridView"
        Me.ProveedorDataGridView.RowHeadersWidth = 51
        Me.ProveedorDataGridView.RowTemplate.Height = 24
        Me.ProveedorDataGridView.Size = New System.Drawing.Size(764, 328)
        Me.ProveedorDataGridView.TabIndex = 0
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LlimpiarProveedor)
        Me.GroupBox3.Controls.Add(Me.EliminarProveedor)
        Me.GroupBox3.Controls.Add(Me.ModificarProveedor)
        Me.GroupBox3.Controls.Add(Me.BuscarProveedores)
        Me.GroupBox3.Controls.Add(Me.MostrarProveedores)
        Me.GroupBox3.Controls.Add(Me.AgregarProveedor)
        Me.GroupBox3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(12, 235)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(353, 135)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Opciones"
        '
        'LlimpiarProveedor
        '
        Me.LlimpiarProveedor.Location = New System.Drawing.Point(247, 86)
        Me.LlimpiarProveedor.Name = "LlimpiarProveedor"
        Me.LlimpiarProveedor.Size = New System.Drawing.Size(94, 39)
        Me.LlimpiarProveedor.TabIndex = 8
        Me.LlimpiarProveedor.Text = "Limpiar"
        Me.LlimpiarProveedor.UseVisualStyleBackColor = True
        '
        'EliminarProveedor
        '
        Me.EliminarProveedor.Location = New System.Drawing.Point(133, 86)
        Me.EliminarProveedor.Name = "EliminarProveedor"
        Me.EliminarProveedor.Size = New System.Drawing.Size(94, 39)
        Me.EliminarProveedor.TabIndex = 7
        Me.EliminarProveedor.Text = "Eliminar"
        Me.EliminarProveedor.UseVisualStyleBackColor = True
        '
        'ModificarProveedor
        '
        Me.ModificarProveedor.Location = New System.Drawing.Point(6, 86)
        Me.ModificarProveedor.Name = "ModificarProveedor"
        Me.ModificarProveedor.Size = New System.Drawing.Size(110, 39)
        Me.ModificarProveedor.TabIndex = 6
        Me.ModificarProveedor.Text = "Modificar"
        Me.ModificarProveedor.UseVisualStyleBackColor = True
        '
        'BuscarProveedores
        '
        Me.BuscarProveedores.Location = New System.Drawing.Point(247, 29)
        Me.BuscarProveedores.Name = "BuscarProveedores"
        Me.BuscarProveedores.Size = New System.Drawing.Size(94, 39)
        Me.BuscarProveedores.TabIndex = 5
        Me.BuscarProveedores.Text = "Buscar"
        Me.BuscarProveedores.UseVisualStyleBackColor = True
        '
        'MostrarProveedores
        '
        Me.MostrarProveedores.Location = New System.Drawing.Point(133, 29)
        Me.MostrarProveedores.Name = "MostrarProveedores"
        Me.MostrarProveedores.Size = New System.Drawing.Size(94, 39)
        Me.MostrarProveedores.TabIndex = 4
        Me.MostrarProveedores.Text = "Mostrar"
        Me.MostrarProveedores.UseVisualStyleBackColor = True
        '
        'AgregarProveedor
        '
        Me.AgregarProveedor.Location = New System.Drawing.Point(15, 29)
        Me.AgregarProveedor.Name = "AgregarProveedor"
        Me.AgregarProveedor.Size = New System.Drawing.Size(94, 39)
        Me.AgregarProveedor.TabIndex = 3
        Me.AgregarProveedor.Text = "Agregar"
        Me.AgregarProveedor.UseVisualStyleBackColor = True
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "CodProveedor"
        Me.DataGridViewTextBoxColumn1.HeaderText = "CodProveedor"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 125
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Nombre"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Nombre"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 125
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Apellido"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Apellido"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 125
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "Direccion"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Direccion"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 125
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "Telefono"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Telefono"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Width = 125
        '
        'ProveedorBindingSource
        '
        Me.ProveedorBindingSource.DataMember = "Proveedor"
        Me.ProveedorBindingSource.DataSource = Me.VeterinariaDataSet
        '
        'VeterinariaDataSet
        '
        Me.VeterinariaDataSet.DataSetName = "VeterinariaDataSet"
        Me.VeterinariaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ProveedorTableAdapter
        '
        Me.ProveedorTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CategoriaTableAdapter = Nothing
        Me.TableAdapterManager.ClienteTableAdapter = Nothing
        Me.TableAdapterManager.DetalleFacturaTableAdapter = Nothing
        Me.TableAdapterManager.DetallePagoTableAdapter = Nothing
        Me.TableAdapterManager.FacturaTableAdapter = Nothing
        Me.TableAdapterManager.MascotaTableAdapter = Nothing
        Me.TableAdapterManager.MedicinaTableAdapter = Nothing
        Me.TableAdapterManager.PagoTableAdapter = Nothing
        Me.TableAdapterManager.ProductoTableAdapter = Nothing
        Me.TableAdapterManager.ProveedorTableAdapter = Me.ProveedorTableAdapter
        Me.TableAdapterManager.ServicioTableAdapter = Nothing
        Me.TableAdapterManager.TipoTableAdapter = Nothing
        Me.TableAdapterManager.TratamientoTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Manchas.VeterinariaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.VacunaTableAdapter = Nothing
        '
        'Proveedores
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ClientSize = New System.Drawing.Size(1178, 400)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Proveedores"
        Me.Text = "Proveedores"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.ProveedorDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        CType(Me.ProveedorBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VeterinariaDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents VeterinariaDataSet As VeterinariaDataSet
    Friend WithEvents ProveedorBindingSource As BindingSource
    Friend WithEvents ProveedorTableAdapter As VeterinariaDataSetTableAdapters.ProveedorTableAdapter
    Friend WithEvents TableAdapterManager As VeterinariaDataSetTableAdapters.TableAdapterManager
    Friend WithEvents ProveedorDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents CodProveedorTextBox As TextBox
    Friend WithEvents NombreProveedor As TextBox
    Friend WithEvents ApellidoProveedor As TextBox
    Friend WithEvents DireccionProveedor As TextBox
    Friend WithEvents TelefonoProveedor As TextBox
    Friend WithEvents LlimpiarProveedor As Button
    Friend WithEvents EliminarProveedor As Button
    Friend WithEvents ModificarProveedor As Button
    Friend WithEvents BuscarProveedores As Button
    Friend WithEvents MostrarProveedores As Button
    Friend WithEvents AgregarProveedor As Button
End Class
