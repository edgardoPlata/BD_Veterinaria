﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Medicina
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim CodMedicinaLabel As System.Windows.Forms.Label
        Dim NombreLabel As System.Windows.Forms.Label
        Dim PrecioLabel As System.Windows.Forms.Label
        Dim FechaVencimeintoLabel As System.Windows.Forms.Label
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.MedicinaDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MedicinaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VeterinariaDataSet = New Manchas.VeterinariaDataSet()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.CodMedicinaTextBox = New System.Windows.Forms.TextBox()
        Me.NombreMedicina = New System.Windows.Forms.TextBox()
        Me.PrecioTextBox = New System.Windows.Forms.TextBox()
        Me.FechaVencimeintoTextBox = New System.Windows.Forms.TextBox()
        Me.LimpiarMEdicina = New System.Windows.Forms.Button()
        Me.MostrarMedicina = New System.Windows.Forms.Button()
        Me.EliminarMEdicina = New System.Windows.Forms.Button()
        Me.BuscarMedicina = New System.Windows.Forms.Button()
        Me.ModicarMEdicina = New System.Windows.Forms.Button()
        Me.AgregarMedicina = New System.Windows.Forms.Button()
        Me.MedicinaTableAdapter = New Manchas.VeterinariaDataSetTableAdapters.MedicinaTableAdapter()
        Me.TableAdapterManager = New Manchas.VeterinariaDataSetTableAdapters.TableAdapterManager()
        CodMedicinaLabel = New System.Windows.Forms.Label()
        NombreLabel = New System.Windows.Forms.Label()
        PrecioLabel = New System.Windows.Forms.Label()
        FechaVencimeintoLabel = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.MedicinaDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MedicinaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VeterinariaDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'CodMedicinaLabel
        '
        CodMedicinaLabel.AutoSize = True
        CodMedicinaLabel.BackColor = System.Drawing.Color.White
        CodMedicinaLabel.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        CodMedicinaLabel.ForeColor = System.Drawing.Color.Black
        CodMedicinaLabel.Location = New System.Drawing.Point(20, 56)
        CodMedicinaLabel.Name = "CodMedicinaLabel"
        CodMedicinaLabel.Size = New System.Drawing.Size(145, 24)
        CodMedicinaLabel.TabIndex = 43
        CodMedicinaLabel.Text = "Cod Medicina:"
        '
        'NombreLabel
        '
        NombreLabel.AutoSize = True
        NombreLabel.BackColor = System.Drawing.Color.White
        NombreLabel.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        NombreLabel.ForeColor = System.Drawing.Color.Black
        NombreLabel.Location = New System.Drawing.Point(20, 101)
        NombreLabel.Name = "NombreLabel"
        NombreLabel.Size = New System.Drawing.Size(91, 24)
        NombreLabel.TabIndex = 45
        NombreLabel.Text = "Nombre:"
        '
        'PrecioLabel
        '
        PrecioLabel.AutoSize = True
        PrecioLabel.BackColor = System.Drawing.Color.White
        PrecioLabel.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        PrecioLabel.ForeColor = System.Drawing.Color.Black
        PrecioLabel.Location = New System.Drawing.Point(20, 146)
        PrecioLabel.Name = "PrecioLabel"
        PrecioLabel.Size = New System.Drawing.Size(77, 24)
        PrecioLabel.TabIndex = 47
        PrecioLabel.Text = "Precio:"
        '
        'FechaVencimeintoLabel
        '
        FechaVencimeintoLabel.AutoSize = True
        FechaVencimeintoLabel.BackColor = System.Drawing.Color.White
        FechaVencimeintoLabel.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        FechaVencimeintoLabel.ForeColor = System.Drawing.Color.Black
        FechaVencimeintoLabel.Location = New System.Drawing.Point(20, 191)
        FechaVencimeintoLabel.Name = "FechaVencimeintoLabel"
        FechaVencimeintoLabel.Size = New System.Drawing.Size(190, 24)
        FechaVencimeintoLabel.TabIndex = 49
        FechaVencimeintoLabel.Text = "fecha Vencimeinto:"
        '
        'GroupBox1
        '
        Me.GroupBox1.BackColor = System.Drawing.Color.IndianRed
        Me.GroupBox1.Controls.Add(Me.MedicinaDataGridView)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.ForeColor = System.Drawing.Color.Black
        Me.GroupBox1.Location = New System.Drawing.Point(496, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(762, 390)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Datos Medicina"
        '
        'MedicinaDataGridView
        '
        Me.MedicinaDataGridView.AutoGenerateColumns = False
        Me.MedicinaDataGridView.BackgroundColor = System.Drawing.SystemColors.ActiveBorder
        Me.MedicinaDataGridView.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.MedicinaDataGridView.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.SingleVertical
        Me.MedicinaDataGridView.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.Sunken
        DataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft
        DataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText
        DataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight
        DataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.ControlText
        DataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.[True]
        Me.MedicinaDataGridView.ColumnHeadersDefaultCellStyle = DataGridViewCellStyle1
        Me.MedicinaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.MedicinaDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4})
        Me.MedicinaDataGridView.DataSource = Me.MedicinaBindingSource
        Me.MedicinaDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MedicinaDataGridView.EnableHeadersVisualStyles = False
        Me.MedicinaDataGridView.Location = New System.Drawing.Point(3, 26)
        Me.MedicinaDataGridView.Name = "MedicinaDataGridView"
        Me.MedicinaDataGridView.RowHeadersWidth = 51
        Me.MedicinaDataGridView.RowTemplate.Height = 24
        Me.MedicinaDataGridView.Size = New System.Drawing.Size(756, 361)
        Me.MedicinaDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "CodMedicina"
        Me.DataGridViewTextBoxColumn1.HeaderText = "CodMedicina"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 125
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Nombre"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Nombre"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 125
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Precio"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Precio"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 125
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "fechaVencimeinto"
        Me.DataGridViewTextBoxColumn4.HeaderText = "fechaVencimeinto"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 125
        '
        'MedicinaBindingSource
        '
        Me.MedicinaBindingSource.DataMember = "Medicina"
        Me.MedicinaBindingSource.DataSource = Me.VeterinariaDataSet
        '
        'VeterinariaDataSet
        '
        Me.VeterinariaDataSet.DataSetName = "VeterinariaDataSet"
        Me.VeterinariaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.Transparent
        Me.GroupBox2.Controls.Add(CodMedicinaLabel)
        Me.GroupBox2.Controls.Add(Me.CodMedicinaTextBox)
        Me.GroupBox2.Controls.Add(NombreLabel)
        Me.GroupBox2.Controls.Add(Me.NombreMedicina)
        Me.GroupBox2.Controls.Add(PrecioLabel)
        Me.GroupBox2.Controls.Add(Me.PrecioTextBox)
        Me.GroupBox2.Controls.Add(FechaVencimeintoLabel)
        Me.GroupBox2.Controls.Add(Me.FechaVencimeintoTextBox)
        Me.GroupBox2.Controls.Add(Me.LimpiarMEdicina)
        Me.GroupBox2.Controls.Add(Me.MostrarMedicina)
        Me.GroupBox2.Controls.Add(Me.EliminarMEdicina)
        Me.GroupBox2.Controls.Add(Me.BuscarMedicina)
        Me.GroupBox2.Controls.Add(Me.ModicarMEdicina)
        Me.GroupBox2.Controls.Add(Me.AgregarMedicina)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Black
        Me.GroupBox2.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(478, 410)
        Me.GroupBox2.TabIndex = 9
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Medicina"
        '
        'CodMedicinaTextBox
        '
        Me.CodMedicinaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MedicinaBindingSource, "CodMedicina", True))
        Me.CodMedicinaTextBox.ForeColor = System.Drawing.Color.Black
        Me.CodMedicinaTextBox.Location = New System.Drawing.Point(230, 53)
        Me.CodMedicinaTextBox.Name = "CodMedicinaTextBox"
        Me.CodMedicinaTextBox.Size = New System.Drawing.Size(186, 30)
        Me.CodMedicinaTextBox.TabIndex = 44
        '
        'NombreMedicina
        '
        Me.NombreMedicina.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MedicinaBindingSource, "Nombre", True))
        Me.NombreMedicina.ForeColor = System.Drawing.Color.Black
        Me.NombreMedicina.Location = New System.Drawing.Point(230, 98)
        Me.NombreMedicina.Name = "NombreMedicina"
        Me.NombreMedicina.Size = New System.Drawing.Size(186, 30)
        Me.NombreMedicina.TabIndex = 46
        '
        'PrecioTextBox
        '
        Me.PrecioTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MedicinaBindingSource, "Precio", True))
        Me.PrecioTextBox.ForeColor = System.Drawing.Color.Black
        Me.PrecioTextBox.Location = New System.Drawing.Point(230, 143)
        Me.PrecioTextBox.Name = "PrecioTextBox"
        Me.PrecioTextBox.Size = New System.Drawing.Size(186, 30)
        Me.PrecioTextBox.TabIndex = 48
        '
        'FechaVencimeintoTextBox
        '
        Me.FechaVencimeintoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MedicinaBindingSource, "fechaVencimeinto", True))
        Me.FechaVencimeintoTextBox.ForeColor = System.Drawing.Color.Black
        Me.FechaVencimeintoTextBox.Location = New System.Drawing.Point(230, 188)
        Me.FechaVencimeintoTextBox.Name = "FechaVencimeintoTextBox"
        Me.FechaVencimeintoTextBox.Size = New System.Drawing.Size(186, 30)
        Me.FechaVencimeintoTextBox.TabIndex = 50
        '
        'LimpiarMEdicina
        '
        Me.LimpiarMEdicina.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.LimpiarMEdicina.ForeColor = System.Drawing.Color.Black
        Me.LimpiarMEdicina.Location = New System.Drawing.Point(15, 349)
        Me.LimpiarMEdicina.Margin = New System.Windows.Forms.Padding(4)
        Me.LimpiarMEdicina.Name = "LimpiarMEdicina"
        Me.LimpiarMEdicina.Size = New System.Drawing.Size(439, 41)
        Me.LimpiarMEdicina.TabIndex = 43
        Me.LimpiarMEdicina.Text = "Limpiar"
        Me.LimpiarMEdicina.UseVisualStyleBackColor = True
        '
        'MostrarMedicina
        '
        Me.MostrarMedicina.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MostrarMedicina.ForeColor = System.Drawing.Color.Black
        Me.MostrarMedicina.Location = New System.Drawing.Point(15, 304)
        Me.MostrarMedicina.Margin = New System.Windows.Forms.Padding(4)
        Me.MostrarMedicina.Name = "MostrarMedicina"
        Me.MostrarMedicina.Size = New System.Drawing.Size(439, 41)
        Me.MostrarMedicina.TabIndex = 41
        Me.MostrarMedicina.Text = "Mostrar"
        Me.MostrarMedicina.UseVisualStyleBackColor = True
        '
        'EliminarMEdicina
        '
        Me.EliminarMEdicina.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.EliminarMEdicina.ForeColor = System.Drawing.Color.Black
        Me.EliminarMEdicina.Location = New System.Drawing.Point(357, 255)
        Me.EliminarMEdicina.Margin = New System.Windows.Forms.Padding(4)
        Me.EliminarMEdicina.Name = "EliminarMEdicina"
        Me.EliminarMEdicina.Size = New System.Drawing.Size(114, 41)
        Me.EliminarMEdicina.TabIndex = 42
        Me.EliminarMEdicina.Text = "Eliminar"
        Me.EliminarMEdicina.UseVisualStyleBackColor = True
        '
        'BuscarMedicina
        '
        Me.BuscarMedicina.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.BuscarMedicina.ForeColor = System.Drawing.Color.Black
        Me.BuscarMedicina.Location = New System.Drawing.Point(121, 255)
        Me.BuscarMedicina.Margin = New System.Windows.Forms.Padding(4)
        Me.BuscarMedicina.Name = "BuscarMedicina"
        Me.BuscarMedicina.Size = New System.Drawing.Size(109, 41)
        Me.BuscarMedicina.TabIndex = 39
        Me.BuscarMedicina.Text = "Buscar"
        Me.BuscarMedicina.UseVisualStyleBackColor = True
        '
        'ModicarMEdicina
        '
        Me.ModicarMEdicina.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ModicarMEdicina.ForeColor = System.Drawing.Color.Black
        Me.ModicarMEdicina.Location = New System.Drawing.Point(238, 255)
        Me.ModicarMEdicina.Margin = New System.Windows.Forms.Padding(4)
        Me.ModicarMEdicina.Name = "ModicarMEdicina"
        Me.ModicarMEdicina.Size = New System.Drawing.Size(111, 41)
        Me.ModicarMEdicina.TabIndex = 37
        Me.ModicarMEdicina.Text = "Actualizar"
        Me.ModicarMEdicina.UseVisualStyleBackColor = True
        '
        'AgregarMedicina
        '
        Me.AgregarMedicina.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.AgregarMedicina.ForeColor = System.Drawing.Color.Black
        Me.AgregarMedicina.Location = New System.Drawing.Point(15, 255)
        Me.AgregarMedicina.Margin = New System.Windows.Forms.Padding(4)
        Me.AgregarMedicina.Name = "AgregarMedicina"
        Me.AgregarMedicina.Size = New System.Drawing.Size(98, 41)
        Me.AgregarMedicina.TabIndex = 36
        Me.AgregarMedicina.Text = "Agregar"
        Me.AgregarMedicina.UseVisualStyleBackColor = True
        '
        'MedicinaTableAdapter
        '
        Me.MedicinaTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CategoriaTableAdapter = Nothing
        Me.TableAdapterManager.ClienteTableAdapter = Nothing
        Me.TableAdapterManager.DetalleFacturaTableAdapter = Nothing
        Me.TableAdapterManager.DetallePagoTableAdapter = Nothing
        Me.TableAdapterManager.FacturaTableAdapter = Nothing
        Me.TableAdapterManager.MascotaTableAdapter = Nothing
        Me.TableAdapterManager.MedicinaTableAdapter = Me.MedicinaTableAdapter
        Me.TableAdapterManager.PagoTableAdapter = Nothing
        Me.TableAdapterManager.ProductoTableAdapter = Nothing
        Me.TableAdapterManager.ProveedorTableAdapter = Nothing
        Me.TableAdapterManager.ServicioTableAdapter = Nothing
        Me.TableAdapterManager.TipoTableAdapter = Nothing
        Me.TableAdapterManager.TratamientoTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Manchas.VeterinariaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.VacunaTableAdapter = Nothing
        '
        'Medicina
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.IndianRed
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1270, 422)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Medicina"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Medicina"
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.MedicinaDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MedicinaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VeterinariaDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents VeterinariaDataSet As VeterinariaDataSet
    Friend WithEvents MedicinaBindingSource As BindingSource
    Friend WithEvents MedicinaTableAdapter As VeterinariaDataSetTableAdapters.MedicinaTableAdapter
    Friend WithEvents TableAdapterManager As VeterinariaDataSetTableAdapters.TableAdapterManager
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents MostrarMedicina As Button
    Friend WithEvents ModicarMEdicina As Button
    Friend WithEvents AgregarMedicina As Button
    Friend WithEvents BuscarMedicina As Button
    Friend WithEvents EliminarMEdicina As Button
    Friend WithEvents LimpiarMEdicina As Button
    Friend WithEvents MedicinaDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents CodMedicinaTextBox As TextBox
    Friend WithEvents NombreMedicina As TextBox
    Friend WithEvents PrecioTextBox As TextBox
    Friend WithEvents FechaVencimeintoTextBox As TextBox
End Class
