﻿Public Class Prove
    Private Sub ProveedorBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.ProveedorBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.VeterinariaDataSet)

    End Sub
    Sub limpiarProveedor()
        CodProveedorTextBox.Clear()
        NombreProveedor.Clear()
        ApellidoProveedor.Clear()
        DireccionProveedor.Clear()
        TelefonoProveedor.Clear()

    End Sub


    Private Sub Proveedores_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'VeterinariaDataSet.Proveedor' Puede moverla o quitarla según sea necesario.
        Me.ProveedorTableAdapter.Fill(Me.VeterinariaDataSet.Proveedor)
        limpiarProveedor()


    End Sub



    Private Sub AgregarProveedor_Click(sender As Object, e As EventArgs) Handles AgregarProveedor.Click
        Me.ProveedorTableAdapter.AgregarProveedor(CodProveedorTextBox.Text, NombreProveedor.Text, ApellidoProveedor.Text, DireccionProveedor.Text, TelefonoProveedor.Text)
        Me.ProveedorTableAdapter.Fill(Me.VeterinariaDataSet.Proveedor)
        limpiarProveedor()
    End Sub

    Private Sub MostrarProveedores_Click(sender As Object, e As EventArgs) Handles MostrarProveedores.Click
        Me.ProveedorTableAdapter.Fill(Me.VeterinariaDataSet.Proveedor)
        limpiarProveedor()
    End Sub

    Private Sub BuscarProveedores_Click(sender As Object, e As EventArgs) Handles BuscarProveedores.Click
        Me.ProveedorTableAdapter.BuscarProveedor(Me.VeterinariaDataSet.Proveedor, CodProveedorTextBox.Text)
    End Sub

    Private Sub ModificarProveedor_Click(sender As Object, e As EventArgs) Handles ModificarProveedor.Click
        Me.ProveedorTableAdapter.ModificarProveedor(CodProveedorTextBox.Text, NombreProveedor.Text, ApellidoProveedor.Text, DireccionProveedor.Text, TelefonoProveedor.Text)
        Me.ProveedorTableAdapter.Fill(Me.VeterinariaDataSet.Proveedor)
        limpiarProveedor()
    End Sub

    Private Sub EliminarProveedor_Click(sender As Object, e As EventArgs) Handles EliminarProveedor.Click
        Me.ProveedorTableAdapter.EliminarProveedor(CodProveedorTextBox.Text)
        Me.ProveedorTableAdapter.Fill(Me.VeterinariaDataSet.Proveedor)
        limpiarProveedor()
    End Sub

    Private Sub LlimpiarProveedor_Click(sender As Object, e As EventArgs) Handles LlimpiarProveedor.Click
        limpiarProveedor()

    End Sub
End Class