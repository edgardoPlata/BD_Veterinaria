﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CRUD_Servicios
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Busqueda_Cliente = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Busqueda_Mascota = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.Telefono_Cliente = New System.Windows.Forms.TextBox()
        Me.Direccion = New System.Windows.Forms.TextBox()
        Me.Apellido_Cliente = New System.Windows.Forms.TextBox()
        Me.Cedula_Cliente = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Nombre_Cliente = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.TXT_Codigo = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Codigo_Cliente_Mascota = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Categoria_Mascota = New System.Windows.Forms.TextBox()
        Me.Peso_Mascota = New System.Windows.Forms.TextBox()
        Me.Tipo_Mascota = New System.Windows.Forms.TextBox()
        Me.Raza_Mascota = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Nombre_Mascota = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Codigo_Mascota = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.Datos_Cliente_ = New System.Windows.Forms.DataGridView()
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.Datos_Mascotas_ = New System.Windows.Forms.DataGridView()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.GroupBox5.SuspendLayout()
        CType(Me.Datos_Cliente_, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        CType(Me.Datos_Mascotas_, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(177, 16)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(159, 25)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Buscar Cliente"
        '
        'Busqueda_Cliente
        '
        Me.Busqueda_Cliente.Location = New System.Drawing.Point(164, 58)
        Me.Busqueda_Cliente.Name = "Busqueda_Cliente"
        Me.Busqueda_Cliente.Size = New System.Drawing.Size(207, 34)
        Me.Busqueda_Cliente.TabIndex = 1
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Busqueda_Mascota)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.Busqueda_Cliente)
        Me.GroupBox1.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(1054, 100)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Busqueda"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(752, 16)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(176, 25)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "Buscar Mascota"
        '
        'Busqueda_Mascota
        '
        Me.Busqueda_Mascota.Location = New System.Drawing.Point(735, 58)
        Me.Busqueda_Mascota.Name = "Busqueda_Mascota"
        Me.Busqueda_Mascota.Size = New System.Drawing.Size(207, 34)
        Me.Busqueda_Mascota.TabIndex = 4
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.Telefono_Cliente)
        Me.GroupBox2.Controls.Add(Me.Direccion)
        Me.GroupBox2.Controls.Add(Me.Apellido_Cliente)
        Me.GroupBox2.Controls.Add(Me.Cedula_Cliente)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Nombre_Cliente)
        Me.GroupBox2.Controls.Add(Me.Label8)
        Me.GroupBox2.Controls.Add(Me.TXT_Codigo)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold)
        Me.GroupBox2.Location = New System.Drawing.Point(12, 118)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(1054, 241)
        Me.GroupBox2.TabIndex = 3
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Cliente"
        '
        'Telefono_Cliente
        '
        Me.Telefono_Cliente.Location = New System.Drawing.Point(765, 191)
        Me.Telefono_Cliente.Name = "Telefono_Cliente"
        Me.Telefono_Cliente.Size = New System.Drawing.Size(277, 34)
        Me.Telefono_Cliente.TabIndex = 11
        '
        'Direccion
        '
        Me.Direccion.Location = New System.Drawing.Point(395, 191)
        Me.Direccion.Name = "Direccion"
        Me.Direccion.Size = New System.Drawing.Size(277, 34)
        Me.Direccion.TabIndex = 11
        '
        'Apellido_Cliente
        '
        Me.Apellido_Cliente.Location = New System.Drawing.Point(765, 89)
        Me.Apellido_Cliente.Name = "Apellido_Cliente"
        Me.Apellido_Cliente.Size = New System.Drawing.Size(277, 34)
        Me.Apellido_Cliente.TabIndex = 9
        '
        'Cedula_Cliente
        '
        Me.Cedula_Cliente.Location = New System.Drawing.Point(12, 191)
        Me.Cedula_Cliente.Name = "Cedula_Cliente"
        Me.Cedula_Cliente.Size = New System.Drawing.Size(277, 34)
        Me.Cedula_Cliente.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(841, 153)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(97, 25)
        Me.Label7.TabIndex = 10
        Me.Label7.Text = "Telefono"
        '
        'Nombre_Cliente
        '
        Me.Nombre_Cliente.Location = New System.Drawing.Point(395, 89)
        Me.Nombre_Cliente.Name = "Nombre_Cliente"
        Me.Nombre_Cliente.Size = New System.Drawing.Size(277, 34)
        Me.Nombre_Cliente.TabIndex = 9
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(841, 51)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(92, 25)
        Me.Label8.TabIndex = 8
        Me.Label8.Text = "Apellido"
        '
        'TXT_Codigo
        '
        Me.TXT_Codigo.Location = New System.Drawing.Point(12, 89)
        Me.TXT_Codigo.Name = "TXT_Codigo"
        Me.TXT_Codigo.Size = New System.Drawing.Size(277, 34)
        Me.TXT_Codigo.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label5.Location = New System.Drawing.Point(472, 153)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(107, 25)
        Me.Label5.TabIndex = 10
        Me.Label5.Text = "Direccion"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(98, 153)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(83, 25)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = "Cedula"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(472, 51)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(94, 25)
        Me.Label6.TabIndex = 8
        Me.Label6.Text = "Nombre"
        Me.Label6.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(98, 51)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(83, 25)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "Codigo"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Codigo_Cliente_Mascota)
        Me.GroupBox3.Controls.Add(Me.Label15)
        Me.GroupBox3.Controls.Add(Me.Categoria_Mascota)
        Me.GroupBox3.Controls.Add(Me.Peso_Mascota)
        Me.GroupBox3.Controls.Add(Me.Tipo_Mascota)
        Me.GroupBox3.Controls.Add(Me.Raza_Mascota)
        Me.GroupBox3.Controls.Add(Me.Label9)
        Me.GroupBox3.Controls.Add(Me.Nombre_Mascota)
        Me.GroupBox3.Controls.Add(Me.Label10)
        Me.GroupBox3.Controls.Add(Me.Codigo_Mascota)
        Me.GroupBox3.Controls.Add(Me.Label11)
        Me.GroupBox3.Controls.Add(Me.Label12)
        Me.GroupBox3.Controls.Add(Me.Label13)
        Me.GroupBox3.Controls.Add(Me.Label14)
        Me.GroupBox3.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold)
        Me.GroupBox3.Location = New System.Drawing.Point(12, 365)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(1054, 337)
        Me.GroupBox3.TabIndex = 4
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Mascota"
        '
        'Codigo_Cliente_Mascota
        '
        Me.Codigo_Cliente_Mascota.Location = New System.Drawing.Point(12, 294)
        Me.Codigo_Cliente_Mascota.Name = "Codigo_Cliente_Mascota"
        Me.Codigo_Cliente_Mascota.Size = New System.Drawing.Size(277, 34)
        Me.Codigo_Cliente_Mascota.TabIndex = 13
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(68, 251)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(159, 25)
        Me.Label15.TabIndex = 12
        Me.Label15.Text = "Codigo Cliente"
        '
        'Categoria_Mascota
        '
        Me.Categoria_Mascota.Location = New System.Drawing.Point(765, 191)
        Me.Categoria_Mascota.Name = "Categoria_Mascota"
        Me.Categoria_Mascota.Size = New System.Drawing.Size(277, 34)
        Me.Categoria_Mascota.TabIndex = 11
        '
        'Peso_Mascota
        '
        Me.Peso_Mascota.Location = New System.Drawing.Point(395, 191)
        Me.Peso_Mascota.Name = "Peso_Mascota"
        Me.Peso_Mascota.Size = New System.Drawing.Size(277, 34)
        Me.Peso_Mascota.TabIndex = 11
        '
        'Tipo_Mascota
        '
        Me.Tipo_Mascota.Location = New System.Drawing.Point(765, 89)
        Me.Tipo_Mascota.Name = "Tipo_Mascota"
        Me.Tipo_Mascota.Size = New System.Drawing.Size(277, 34)
        Me.Tipo_Mascota.TabIndex = 9
        '
        'Raza_Mascota
        '
        Me.Raza_Mascota.Location = New System.Drawing.Point(12, 191)
        Me.Raza_Mascota.Name = "Raza_Mascota"
        Me.Raza_Mascota.Size = New System.Drawing.Size(277, 34)
        Me.Raza_Mascota.TabIndex = 7
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label9.Location = New System.Drawing.Point(841, 153)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(111, 25)
        Me.Label9.TabIndex = 10
        Me.Label9.Text = "Categoria"
        '
        'Nombre_Mascota
        '
        Me.Nombre_Mascota.Location = New System.Drawing.Point(395, 89)
        Me.Nombre_Mascota.Name = "Nombre_Mascota"
        Me.Nombre_Mascota.Size = New System.Drawing.Size(277, 34)
        Me.Nombre_Mascota.TabIndex = 9
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label10.Location = New System.Drawing.Point(841, 51)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(57, 25)
        Me.Label10.TabIndex = 8
        Me.Label10.Text = "Tipo"
        '
        'Codigo_Mascota
        '
        Me.Codigo_Mascota.Location = New System.Drawing.Point(12, 89)
        Me.Codigo_Mascota.Name = "Codigo_Mascota"
        Me.Codigo_Mascota.Size = New System.Drawing.Size(277, 34)
        Me.Codigo_Mascota.TabIndex = 5
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label11.Location = New System.Drawing.Point(491, 153)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(59, 25)
        Me.Label11.TabIndex = 10
        Me.Label11.Text = "Peso"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(98, 153)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(62, 25)
        Me.Label12.TabIndex = 6
        Me.Label12.Text = "Raza"
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label13.Location = New System.Drawing.Point(491, 51)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(94, 25)
        Me.Label13.TabIndex = 8
        Me.Label13.Text = "Nombre"
        Me.Label13.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(98, 51)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(83, 25)
        Me.Label14.TabIndex = 4
        Me.Label14.Text = "Codigo"
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.Button2)
        Me.GroupBox4.Controls.Add(Me.Button1)
        Me.GroupBox4.Location = New System.Drawing.Point(278, 708)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(601, 106)
        Me.GroupBox4.TabIndex = 5
        Me.GroupBox4.TabStop = False
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold)
        Me.Button2.Location = New System.Drawing.Point(366, 21)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(200, 63)
        Me.Button2.TabIndex = 6
        Me.Button2.Text = "Modificar"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold)
        Me.Button1.Location = New System.Drawing.Point(22, 21)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(202, 63)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Agregar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.Datos_Cliente_)
        Me.GroupBox5.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold)
        Me.GroupBox5.Location = New System.Drawing.Point(1097, 28)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(943, 374)
        Me.GroupBox5.TabIndex = 6
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Datos Clientes"
        '
        'Datos_Cliente_
        '
        Me.Datos_Cliente_.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Datos_Cliente_.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Datos_Cliente_.Location = New System.Drawing.Point(3, 30)
        Me.Datos_Cliente_.Name = "Datos_Cliente_"
        Me.Datos_Cliente_.RowHeadersWidth = 51
        Me.Datos_Cliente_.RowTemplate.Height = 24
        Me.Datos_Cliente_.Size = New System.Drawing.Size(937, 341)
        Me.Datos_Cliente_.TabIndex = 0
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.Datos_Mascotas_)
        Me.GroupBox6.Font = New System.Drawing.Font("Times New Roman", 13.8!, System.Drawing.FontStyle.Bold)
        Me.GroupBox6.Location = New System.Drawing.Point(1100, 420)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(932, 421)
        Me.GroupBox6.TabIndex = 7
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Datos Mascotas"
        '
        'Datos_Mascotas_
        '
        Me.Datos_Mascotas_.AllowUserToOrderColumns = True
        Me.Datos_Mascotas_.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.Datos_Mascotas_.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Datos_Mascotas_.Location = New System.Drawing.Point(3, 30)
        Me.Datos_Mascotas_.Name = "Datos_Mascotas_"
        Me.Datos_Mascotas_.RowHeadersWidth = 51
        Me.Datos_Mascotas_.RowTemplate.Height = 24
        Me.Datos_Mascotas_.Size = New System.Drawing.Size(926, 388)
        Me.Datos_Mascotas_.TabIndex = 0
        '
        'CRUD_Servicios
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(2182, 1043)
        Me.Controls.Add(Me.GroupBox6)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "CRUD_Servicios"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "CRUD_Servicios"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox3.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.Datos_Cliente_, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        CType(Me.Datos_Mascotas_, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents Label1 As Label
    Friend WithEvents Busqueda_Cliente As TextBox
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents Label2 As Label
    Friend WithEvents Busqueda_Mascota As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents Telefono_Cliente As TextBox
    Friend WithEvents Direccion As TextBox
    Friend WithEvents Apellido_Cliente As TextBox
    Friend WithEvents Cedula_Cliente As TextBox
    Friend WithEvents Label7 As Label
    Friend WithEvents Nombre_Cliente As TextBox
    Friend WithEvents Label8 As Label
    Friend WithEvents TXT_Codigo As TextBox
    Friend WithEvents Label5 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Codigo_Cliente_Mascota As TextBox
    Friend WithEvents Label15 As Label
    Friend WithEvents Categoria_Mascota As TextBox
    Friend WithEvents Peso_Mascota As TextBox
    Friend WithEvents Tipo_Mascota As TextBox
    Friend WithEvents Raza_Mascota As TextBox
    Friend WithEvents Label9 As Label
    Friend WithEvents Nombre_Mascota As TextBox
    Friend WithEvents Label10 As Label
    Friend WithEvents Codigo_Mascota As TextBox
    Friend WithEvents Label11 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents Label13 As Label
    Friend WithEvents Label14 As Label
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents Datos_Cliente_ As DataGridView
    Friend WithEvents GroupBox6 As GroupBox

    Friend WithEvents CodClienteDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NombreDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ApellidoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CedulaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DireccionDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TelefonoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents Datos_Mascotas_ As DataGridView

    Friend WithEvents CodMascotaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents NombreDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents IdTipoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents RazaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PesoDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents IdClienteDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents IdCategoriaDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
