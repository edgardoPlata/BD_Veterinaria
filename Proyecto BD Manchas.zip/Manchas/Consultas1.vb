﻿Public Class Consultas1
    Private Sub PagoBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.PagoBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.VeterinariaDataSet)

    End Sub
    Sub LimpiarPagos()
        CodPagoTextBox.Clear()
        FechaPago.Clear()
        IdClientePago.Clear()

    End Sub
    Sub LimpiarFacturas()
        NumeroFacturaTextBox.Clear()
        FechaFactura.Clear()
        IdProveedorTextBox.Clear()
        IdMedicinaTextBox.Clear()

    End Sub

    Private Sub Consultas1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'VeterinariaDataSet.Medicina' Puede moverla o quitarla según sea necesario.
        Me.MedicinaTableAdapter.Fill(Me.VeterinariaDataSet.Medicina)
        'TODO: esta línea de código carga datos en la tabla 'VeterinariaDataSet.Proveedor' Puede moverla o quitarla según sea necesario.
        Me.ProveedorTableAdapter.Fill(Me.VeterinariaDataSet.Proveedor)
        'TODO: esta línea de código carga datos en la tabla 'VeterinariaDataSet.Cliente' Puede moverla o quitarla según sea necesario.
        Me.ClienteTableAdapter.Fill(Me.VeterinariaDataSet.Cliente)
        'TODO: esta línea de código carga datos en la tabla 'VeterinariaDataSet.Factura' Puede moverla o quitarla según sea necesario.
        Me.FacturaTableAdapter.Fill(Me.VeterinariaDataSet.Factura)
        'TODO: esta línea de código carga datos en la tabla 'VeterinariaDataSet.Pago' Puede moverla o quitarla según sea necesario.
        Me.PagoTableAdapter.Fill(Me.VeterinariaDataSet.Pago)
        LimpiarPagos()
        LimpiarFacturas()




    End Sub

    Private Sub TabPage1_Click(sender As Object, e As EventArgs) Handles TabPage1.Click

    End Sub

    Private Sub AgregarPago_Click(sender As Object, e As EventArgs) Handles AgregarPago.Click
        Me.PagoTableAdapter.AgregarPago(CodPagoTextBox.Text, FechaPago.Text, IdClientePago.Text)
        Me.PagoTableAdapter.Fill(Me.VeterinariaDataSet.Pago)
        LimpiarPagos()

    End Sub

    Private Sub MostrarPAgo_Click(sender As Object, e As EventArgs) Handles MostrarPAgo.Click
        Me.PagoTableAdapter.Fill(Me.VeterinariaDataSet.Pago)
        LimpiarPagos()

    End Sub

    Private Sub BuscarPago_Click(sender As Object, e As EventArgs) Handles BuscarPago.Click
        Me.PagoTableAdapter.BuscarPAgo(Me.VeterinariaDataSet.Pago, CodPagoTextBox.Text)
    End Sub

    Private Sub ModificarPago_Click(sender As Object, e As EventArgs) Handles ModificarPago.Click
        Me.PagoTableAdapter.ModificarPago(CodPagoTextBox.Text, FechaPago.Text, IdClientePago.Text)
        Me.PagoTableAdapter.Fill(Me.VeterinariaDataSet.Pago)
        LimpiarPagos()
    End Sub

    Private Sub EliminarPago_Click(sender As Object, e As EventArgs) Handles EliminarPago.Click
        Me.PagoTableAdapter.EliminarPago(CodPagoTextBox.Text)
        Me.PagoTableAdapter.Fill(Me.VeterinariaDataSet.Pago)
        LimpiarPagos()
    End Sub

    Private Sub AgregarFactura_Click(sender As Object, e As EventArgs) Handles AgregarFactura.Click
        Me.FacturaTableAdapter.AgregarFactura(NumeroFacturaTextBox.Text, FechaFactura.Text, IdProveedorTextBox.Text, IdMedicinaTextBox.Text)
        Me.FacturaTableAdapter.Fill(Me.VeterinariaDataSet.Factura)
        LimpiarFacturas()

    End Sub

    Private Sub MostrarFactura_Click(sender As Object, e As EventArgs) Handles MostrarFactura.Click

        Me.FacturaTableAdapter.Fill(Me.VeterinariaDataSet.Factura)
        LimpiarFacturas()

    End Sub


    Private Sub BuscarFactura_Click(sender As Object, e As EventArgs) Handles BuscarFactura.Click
        Me.FacturaTableAdapter.BuscarFactura(Me.VeterinariaDataSet.Factura, NumeroFacturaTextBox.Text)

    End Sub

    Private Sub ModificarFactura_Click(sender As Object, e As EventArgs) Handles ModificarFactura.Click
        Me.FacturaTableAdapter.ModificarFactura(NumeroFacturaTextBox.Text, FechaFactura.Text, IdProveedorTextBox.Text, IdMedicinaTextBox.Text)
        Me.FacturaTableAdapter.Fill(Me.VeterinariaDataSet.Factura)
        LimpiarFacturas()
    End Sub

    Private Sub EliminarFactura_Click(sender As Object, e As EventArgs) Handles EliminarFactura.Click
        Me.FacturaTableAdapter.EliminarFactura(NumeroFacturaTextBox.Text)
        Me.FacturaTableAdapter.Fill(Me.VeterinariaDataSet.Factura)
        LimpiarFacturas()
    End Sub

    Private Sub LimpiarFactura_Click(sender As Object, e As EventArgs) Handles LimpiarFactura.Click
        LimpiarFacturas()


    End Sub

    Private Sub LimpiarPago_Click(sender As Object, e As EventArgs) Handles LimpiarPago.Click
        LimpiarPagos()

    End Sub


End Class