﻿
Imports System.Data.SqlClient

Public Class Principal


    Private Sub Principal_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Abrir_Conexion()

    End Sub

    Private Sub ServiciosMenu_Click(sender As Object, e As EventArgs) Handles ServiciosMenu.Click

        My.Forms.Servicios.Show()


    End Sub

    Private Sub MedicinaMEnu_Click(sender As Object, e As EventArgs) Handles MedicinaMEnu.Click
        Medicina.Show()

    End Sub

    Private Sub TratamientoMenu_Click(sender As Object, e As EventArgs) Handles TratamientoMenu.Click
        Tratamiento.Show()

    End Sub

    Private Sub VacunaMenu_Click(sender As Object, e As EventArgs) Handles VacunaMenu.Click
        Vacuna.Show()

    End Sub

    Private Sub ProveedoresMenu_Click(sender As Object, e As EventArgs) Handles ProveedoresMenu.Click
        Prove.Show()

    End Sub

    Private Sub ConsultasMenu_Click(sender As Object, e As EventArgs) Handles ConsultasMenu.Click
        Consultas1.Show()

    End Sub
End Class
