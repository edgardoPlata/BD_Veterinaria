﻿Public Class Servicios
    Private Sub ClienteBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.ClienteBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.VeterinariaDataSet)

    End Sub

    Sub LimpiarCliente()
        CodClienteTextBox.Clear()
        NombreCliente.Clear()
        ApellidoTextBox.Clear()
        CedulaTextBox.Clear()
        DireccionTextBox.Clear()
        TelefonoTextBox.Clear()

    End Sub
    Sub LimpiarMascota()
        CodMascotaTextBox.Clear()
        NombreMascota.Clear()
        IdTipoTextBox.Clear()
        RazaTextBox.Clear()
        PesoTextBox.Clear()
        IdClienteTextBox.Clear()
        TipoServicioTextBox.Clear()
    End Sub

    Private Sub Servicios_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'VeterinariaDataSet.Mascota' Puede moverla o quitarla según sea necesario.
        Me.MascotaTableAdapter.Fill(Me.VeterinariaDataSet.Mascota)
        'TODO: esta línea de código carga datos en la tabla 'VeterinariaDataSet.Cliente' Puede moverla o quitarla según sea necesario.
        Me.ClienteTableAdapter.Fill(Me.VeterinariaDataSet.Cliente)
        LimpiarCliente()
        LimpiarMascota()

    End Sub

    Private Sub AgregarCliente_Click(sender As Object, e As EventArgs) Handles AgregarCliente.Click
        Me.ClienteTableAdapter.AgregarCliente(CodClienteTextBox.Text, NombreCliente.Text, ApellidoTextBox.Text, CedulaTextBox.Text, DireccionTextBox.Text, TelefonoTextBox.Text)
        Me.ClienteTableAdapter.Fill(Me.VeterinariaDataSet.Cliente)
        LimpiarCliente()

    End Sub

    Private Sub Mostrar_Click(sender As Object, e As EventArgs) Handles Mostrar.Click
        Me.ClienteTableAdapter.Fill(Me.VeterinariaDataSet.Cliente)
        LimpiarCliente()
    End Sub

    Private Sub BuscarCliente_Click(sender As Object, e As EventArgs) Handles BuscarCliente.Click

        Me.ClienteTableAdapter.BuscarCliente1(Me.VeterinariaDataSet.Cliente, CodClienteTextBox.Text)
    End Sub

    Private Sub ModificarCliente_Click(sender As Object, e As EventArgs) Handles ModificarCliente.Click

        Me.ClienteTableAdapter.EditarCliente(CodClienteTextBox.Text, NombreCliente.Text, ApellidoTextBox.Text, CedulaTextBox.Text, DireccionTextBox.Text, TelefonoTextBox.Text)
        Me.ClienteTableAdapter.Fill(Me.VeterinariaDataSet.Cliente)
        LimpiarCliente()


    End Sub

    Private Sub EliminarCliente_Click(sender As Object, e As EventArgs) Handles EliminarCliente.Click
        Me.ClienteTableAdapter.EliminarCliente(CodClienteTextBox.Text)
        Me.ClienteTableAdapter.Fill(Me.VeterinariaDataSet.Cliente)
        LimpiarCliente()

    End Sub

    Private Sub AgregarMascota_Click(sender As Object, e As EventArgs) Handles AgregarMascota.Click
        Me.MascotaTableAdapter.AgregarMascota(CodMascotaTextBox.Text, NombreMascota.Text, IdTipoTextBox.Text, RazaTextBox.Text, PesoTextBox.Text, IdClienteTextBox.Text, TipoServicioTextBox.Text)
        Me.MascotaTableAdapter.Fill(Me.VeterinariaDataSet.Mascota)
        LimpiarMascota()

    End Sub

    Private Sub MostrarMAscota_Click(sender As Object, e As EventArgs) Handles MostrarMAscota.Click
        Me.MascotaTableAdapter.Fill(Me.VeterinariaDataSet.Mascota)
        LimpiarMascota()

    End Sub

    Private Sub ModificarMascota_Click(sender As Object, e As EventArgs) Handles ModificarMascota.Click
        Me.MascotaTableAdapter.ModificarMascota(CodMascotaTextBox.Text, NombreMascota.Text, IdTipoTextBox.Text, RazaTextBox.Text, PesoTextBox.Text, IdClienteTextBox.Text, TipoServicioTextBox.Text)
        Me.MascotaTableAdapter.Fill(Me.VeterinariaDataSet.Mascota)
        LimpiarMascota()

    End Sub

    Private Sub BuscarMAscota_Click(sender As Object, e As EventArgs) Handles BuscarMAscota.Click
        Me.MascotaTableAdapter.BuscarMascota(Me.VeterinariaDataSet.Mascota, CodClienteTextBox.Text)
    End Sub

    Private Sub EliminarMascota_Click(sender As Object, e As EventArgs) Handles EliminarMascota.Click
        Me.MascotaTableAdapter.EliminarMascota(CodClienteTextBox.Text)
        Me.MascotaTableAdapter.Fill(Me.VeterinariaDataSet.Mascota)
        LimpiarMascota()

    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        LimpiarCliente()

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        LimpiarMascota()

    End Sub
End Class