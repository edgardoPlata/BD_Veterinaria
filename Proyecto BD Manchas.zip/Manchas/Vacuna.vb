﻿Public Class Vacuna

    Sub LimpiarVacunacion()
        CodVacunaTextBox.Clear()
        FechaTextBox.Clear()
        NumeroVacunaTextBox.Clear()
        DescripcionTextBox.Clear()
        IdMascotaTextBox.Clear()
        IdClienteTextBox.Clear()
    End Sub

    Private Sub Vacuna_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'VeterinariaDataSet.Vacuna' Puede moverla o quitarla según sea necesario.
        Me.VacunaTableAdapter.Fill(Me.VeterinariaDataSet.Vacuna)
        LimpiarVacunacion()
    End Sub

    Private Sub AgregarVacuna_Click(sender As Object, e As EventArgs) Handles AgregarVacuna.Click
        Me.VacunaTableAdapter.AgregarVacuna(CodVacunaTextBox.Text, FechaTextBox.Text, NumeroVacunaTextBox.Text, DescripcionTextBox.Text, IdMascotaTextBox.Text, IdClienteTextBox.Text)
        Me.VacunaTableAdapter.Fill(Me.VeterinariaDataSet.Vacuna)
        LimpiarVacunacion()

    End Sub

    Private Sub MostrarVAcuna_Click(sender As Object, e As EventArgs) Handles MostrarVAcuna.Click
        Me.VacunaTableAdapter.Fill(Me.VeterinariaDataSet.Vacuna)
        LimpiarVacunacion()
    End Sub

    Private Sub BuscarVacuna_Click(sender As Object, e As EventArgs) Handles BuscarVacuna.Click
        Me.VacunaTableAdapter.BuscarVacuna(Me.VeterinariaDataSet.Vacuna, CodVacunaTextBox.Text)
    End Sub

    Private Sub ModificarVAcuna_Click(sender As Object, e As EventArgs) Handles ModificarVAcuna.Click
        Me.VacunaTableAdapter.ModificarVacuna(CodVacunaTextBox.Text, FechaTextBox.Text, NumeroVacunaTextBox.Text, DescripcionTextBox.Text, IdMascotaTextBox.Text, IdClienteTextBox.Text)
        Me.VacunaTableAdapter.Fill(Me.VeterinariaDataSet.Vacuna)
        LimpiarVacunacion()
    End Sub

    Private Sub EliminarVacuna_Click(sender As Object, e As EventArgs) Handles EliminarVacuna.Click
        Me.VacunaTableAdapter.EliminarVacuna(CodVacunaTextBox.Text)
        Me.VacunaTableAdapter.Fill(Me.VeterinariaDataSet.Vacuna)
        LimpiarVacunacion()
    End Sub

    Private Sub LimpiarVacuna_Click(sender As Object, e As EventArgs) Handles LimpiarVacuna.Click
        LimpiarVacunacion()
    End Sub
End Class