﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Vacuna
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim CodVacunaLabel As System.Windows.Forms.Label
        Dim FechaLabel As System.Windows.Forms.Label
        Dim NumeroVacunaLabel As System.Windows.Forms.Label
        Dim DescripcionLabel As System.Windows.Forms.Label
        Dim IdMascotaLabel As System.Windows.Forms.Label
        Dim IdClienteLabel As System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CodVacunaTextBox = New System.Windows.Forms.TextBox()
        Me.VacunaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VeterinariaDataSet = New Manchas.VeterinariaDataSet()
        Me.FechaTextBox = New System.Windows.Forms.TextBox()
        Me.NumeroVacunaTextBox = New System.Windows.Forms.TextBox()
        Me.DescripcionTextBox = New System.Windows.Forms.TextBox()
        Me.IdMascotaTextBox = New System.Windows.Forms.TextBox()
        Me.IdClienteTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.VacunaDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.LimpiarVacuna = New System.Windows.Forms.Button()
        Me.EliminarVacuna = New System.Windows.Forms.Button()
        Me.ModificarVAcuna = New System.Windows.Forms.Button()
        Me.BuscarVacuna = New System.Windows.Forms.Button()
        Me.MostrarVAcuna = New System.Windows.Forms.Button()
        Me.AgregarVacuna = New System.Windows.Forms.Button()
        Me.VacunaTableAdapter = New Manchas.VeterinariaDataSetTableAdapters.VacunaTableAdapter()
        Me.TableAdapterManager = New Manchas.VeterinariaDataSetTableAdapters.TableAdapterManager()
        CodVacunaLabel = New System.Windows.Forms.Label()
        FechaLabel = New System.Windows.Forms.Label()
        NumeroVacunaLabel = New System.Windows.Forms.Label()
        DescripcionLabel = New System.Windows.Forms.Label()
        IdMascotaLabel = New System.Windows.Forms.Label()
        IdClienteLabel = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.VacunaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VeterinariaDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.VacunaDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'CodVacunaLabel
        '
        CodVacunaLabel.AutoSize = True
        CodVacunaLabel.Location = New System.Drawing.Point(15, 44)
        CodVacunaLabel.Name = "CodVacunaLabel"
        CodVacunaLabel.Size = New System.Drawing.Size(130, 24)
        CodVacunaLabel.TabIndex = 0
        CodVacunaLabel.Text = "Cod Vacuna:"
        '
        'FechaLabel
        '
        FechaLabel.AutoSize = True
        FechaLabel.Location = New System.Drawing.Point(15, 80)
        FechaLabel.Name = "FechaLabel"
        FechaLabel.Size = New System.Drawing.Size(74, 24)
        FechaLabel.TabIndex = 2
        FechaLabel.Text = "Fecha:"
        '
        'NumeroVacunaLabel
        '
        NumeroVacunaLabel.AutoSize = True
        NumeroVacunaLabel.Location = New System.Drawing.Point(15, 116)
        NumeroVacunaLabel.Name = "NumeroVacunaLabel"
        NumeroVacunaLabel.Size = New System.Drawing.Size(166, 24)
        NumeroVacunaLabel.TabIndex = 4
        NumeroVacunaLabel.Text = "Numero Vacuna:"
        '
        'DescripcionLabel
        '
        DescripcionLabel.AutoSize = True
        DescripcionLabel.Location = New System.Drawing.Point(15, 152)
        DescripcionLabel.Name = "DescripcionLabel"
        DescripcionLabel.Size = New System.Drawing.Size(129, 24)
        DescripcionLabel.TabIndex = 6
        DescripcionLabel.Text = "Descripcion:"
        '
        'IdMascotaLabel
        '
        IdMascotaLabel.AutoSize = True
        IdMascotaLabel.Location = New System.Drawing.Point(15, 188)
        IdMascotaLabel.Name = "IdMascotaLabel"
        IdMascotaLabel.Size = New System.Drawing.Size(120, 24)
        IdMascotaLabel.TabIndex = 8
        IdMascotaLabel.Text = "Id Mascota:"
        '
        'IdClienteLabel
        '
        IdClienteLabel.AutoSize = True
        IdClienteLabel.Location = New System.Drawing.Point(15, 224)
        IdClienteLabel.Name = "IdClienteLabel"
        IdClienteLabel.Size = New System.Drawing.Size(105, 24)
        IdClienteLabel.TabIndex = 10
        IdClienteLabel.Text = "Id Cliente:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(CodVacunaLabel)
        Me.GroupBox1.Controls.Add(Me.CodVacunaTextBox)
        Me.GroupBox1.Controls.Add(FechaLabel)
        Me.GroupBox1.Controls.Add(Me.FechaTextBox)
        Me.GroupBox1.Controls.Add(NumeroVacunaLabel)
        Me.GroupBox1.Controls.Add(Me.NumeroVacunaTextBox)
        Me.GroupBox1.Controls.Add(DescripcionLabel)
        Me.GroupBox1.Controls.Add(Me.DescripcionTextBox)
        Me.GroupBox1.Controls.Add(IdMascotaLabel)
        Me.GroupBox1.Controls.Add(Me.IdMascotaTextBox)
        Me.GroupBox1.Controls.Add(IdClienteLabel)
        Me.GroupBox1.Controls.Add(Me.IdClienteTextBox)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(402, 265)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Vacunas"
        '
        'CodVacunaTextBox
        '
        Me.CodVacunaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.VacunaBindingSource, "CodVacuna", True))
        Me.CodVacunaTextBox.Location = New System.Drawing.Point(202, 41)
        Me.CodVacunaTextBox.Name = "CodVacunaTextBox"
        Me.CodVacunaTextBox.Size = New System.Drawing.Size(194, 30)
        Me.CodVacunaTextBox.TabIndex = 1
        '
        'VacunaBindingSource
        '
        Me.VacunaBindingSource.DataMember = "Vacuna"
        Me.VacunaBindingSource.DataSource = Me.VeterinariaDataSet
        '
        'VeterinariaDataSet
        '
        Me.VeterinariaDataSet.DataSetName = "VeterinariaDataSet"
        Me.VeterinariaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'FechaTextBox
        '
        Me.FechaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.VacunaBindingSource, "Fecha", True))
        Me.FechaTextBox.Location = New System.Drawing.Point(202, 77)
        Me.FechaTextBox.Name = "FechaTextBox"
        Me.FechaTextBox.Size = New System.Drawing.Size(194, 30)
        Me.FechaTextBox.TabIndex = 3
        '
        'NumeroVacunaTextBox
        '
        Me.NumeroVacunaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.VacunaBindingSource, "NumeroVacuna", True))
        Me.NumeroVacunaTextBox.Location = New System.Drawing.Point(202, 113)
        Me.NumeroVacunaTextBox.Name = "NumeroVacunaTextBox"
        Me.NumeroVacunaTextBox.Size = New System.Drawing.Size(194, 30)
        Me.NumeroVacunaTextBox.TabIndex = 5
        '
        'DescripcionTextBox
        '
        Me.DescripcionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.VacunaBindingSource, "Descripcion", True))
        Me.DescripcionTextBox.Location = New System.Drawing.Point(202, 149)
        Me.DescripcionTextBox.Name = "DescripcionTextBox"
        Me.DescripcionTextBox.Size = New System.Drawing.Size(194, 30)
        Me.DescripcionTextBox.TabIndex = 7
        '
        'IdMascotaTextBox
        '
        Me.IdMascotaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.VacunaBindingSource, "IdMascota", True))
        Me.IdMascotaTextBox.Location = New System.Drawing.Point(202, 185)
        Me.IdMascotaTextBox.Name = "IdMascotaTextBox"
        Me.IdMascotaTextBox.Size = New System.Drawing.Size(194, 30)
        Me.IdMascotaTextBox.TabIndex = 9
        '
        'IdClienteTextBox
        '
        Me.IdClienteTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.VacunaBindingSource, "IdCliente", True))
        Me.IdClienteTextBox.Location = New System.Drawing.Point(202, 221)
        Me.IdClienteTextBox.Name = "IdClienteTextBox"
        Me.IdClienteTextBox.Size = New System.Drawing.Size(194, 30)
        Me.IdClienteTextBox.TabIndex = 11
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.VacunaDataGridView)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(420, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(824, 403)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Datos Vacunacion"
        '
        'VacunaDataGridView
        '
        Me.VacunaDataGridView.AutoGenerateColumns = False
        Me.VacunaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.VacunaDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6})
        Me.VacunaDataGridView.DataSource = Me.VacunaBindingSource
        Me.VacunaDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.VacunaDataGridView.Location = New System.Drawing.Point(3, 26)
        Me.VacunaDataGridView.Name = "VacunaDataGridView"
        Me.VacunaDataGridView.RowHeadersWidth = 51
        Me.VacunaDataGridView.RowTemplate.Height = 24
        Me.VacunaDataGridView.Size = New System.Drawing.Size(818, 374)
        Me.VacunaDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "CodVacuna"
        Me.DataGridViewTextBoxColumn1.HeaderText = "CodVacuna"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 125
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Fecha"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Fecha"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 125
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "NumeroVacuna"
        Me.DataGridViewTextBoxColumn3.HeaderText = "NumeroVacuna"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 125
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "Descripcion"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Descripcion"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 125
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "IdMascota"
        Me.DataGridViewTextBoxColumn5.HeaderText = "IdMascota"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Width = 125
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "IdCliente"
        Me.DataGridViewTextBoxColumn6.HeaderText = "IdCliente"
        Me.DataGridViewTextBoxColumn6.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Width = 125
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LimpiarVacuna)
        Me.GroupBox3.Controls.Add(Me.EliminarVacuna)
        Me.GroupBox3.Controls.Add(Me.ModificarVAcuna)
        Me.GroupBox3.Controls.Add(Me.BuscarVacuna)
        Me.GroupBox3.Controls.Add(Me.MostrarVAcuna)
        Me.GroupBox3.Controls.Add(Me.AgregarVacuna)
        Me.GroupBox3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(12, 296)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(387, 125)
        Me.GroupBox3.TabIndex = 3
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Opciones"
        '
        'LimpiarVacuna
        '
        Me.LimpiarVacuna.Location = New System.Drawing.Point(268, 84)
        Me.LimpiarVacuna.Name = "LimpiarVacuna"
        Me.LimpiarVacuna.Size = New System.Drawing.Size(101, 35)
        Me.LimpiarVacuna.TabIndex = 8
        Me.LimpiarVacuna.Text = "Limpiar"
        Me.LimpiarVacuna.UseVisualStyleBackColor = True
        '
        'EliminarVacuna
        '
        Me.EliminarVacuna.Location = New System.Drawing.Point(134, 84)
        Me.EliminarVacuna.Name = "EliminarVacuna"
        Me.EliminarVacuna.Size = New System.Drawing.Size(101, 35)
        Me.EliminarVacuna.TabIndex = 7
        Me.EliminarVacuna.Text = "Eliminar"
        Me.EliminarVacuna.UseVisualStyleBackColor = True
        '
        'ModificarVAcuna
        '
        Me.ModificarVAcuna.Location = New System.Drawing.Point(6, 84)
        Me.ModificarVAcuna.Name = "ModificarVAcuna"
        Me.ModificarVAcuna.Size = New System.Drawing.Size(101, 35)
        Me.ModificarVAcuna.TabIndex = 6
        Me.ModificarVAcuna.Text = "Modificar"
        Me.ModificarVAcuna.UseVisualStyleBackColor = True
        '
        'BuscarVacuna
        '
        Me.BuscarVacuna.Location = New System.Drawing.Point(268, 38)
        Me.BuscarVacuna.Name = "BuscarVacuna"
        Me.BuscarVacuna.Size = New System.Drawing.Size(101, 35)
        Me.BuscarVacuna.TabIndex = 5
        Me.BuscarVacuna.Text = "Buscar"
        Me.BuscarVacuna.UseVisualStyleBackColor = True
        '
        'MostrarVAcuna
        '
        Me.MostrarVAcuna.Location = New System.Drawing.Point(134, 38)
        Me.MostrarVAcuna.Name = "MostrarVAcuna"
        Me.MostrarVAcuna.Size = New System.Drawing.Size(101, 35)
        Me.MostrarVAcuna.TabIndex = 5
        Me.MostrarVAcuna.Text = "Mostrar"
        Me.MostrarVAcuna.UseVisualStyleBackColor = True
        '
        'AgregarVacuna
        '
        Me.AgregarVacuna.Location = New System.Drawing.Point(6, 38)
        Me.AgregarVacuna.Name = "AgregarVacuna"
        Me.AgregarVacuna.Size = New System.Drawing.Size(101, 35)
        Me.AgregarVacuna.TabIndex = 4
        Me.AgregarVacuna.Text = "Agregar"
        Me.AgregarVacuna.UseVisualStyleBackColor = True
        '
        'VacunaTableAdapter
        '
        Me.VacunaTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CategoriaTableAdapter = Nothing
        Me.TableAdapterManager.ClienteTableAdapter = Nothing
        Me.TableAdapterManager.DetalleFacturaTableAdapter = Nothing
        Me.TableAdapterManager.DetallePagoTableAdapter = Nothing
        Me.TableAdapterManager.FacturaTableAdapter = Nothing
        Me.TableAdapterManager.MascotaTableAdapter = Nothing
        Me.TableAdapterManager.MedicinaTableAdapter = Nothing
        Me.TableAdapterManager.PagoTableAdapter = Nothing
        Me.TableAdapterManager.ProductoTableAdapter = Nothing
        Me.TableAdapterManager.ProveedorTableAdapter = Nothing
        Me.TableAdapterManager.ServicioTableAdapter = Nothing
        Me.TableAdapterManager.TipoTableAdapter = Nothing
        Me.TableAdapterManager.TratamientoTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Manchas.VeterinariaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.VacunaTableAdapter = Me.VacunaTableAdapter
        '
        'Vacuna
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Cyan
        Me.ClientSize = New System.Drawing.Size(1241, 432)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Vacuna"
        Me.Text = "Vacuna"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.VacunaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VeterinariaDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.VacunaDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents VeterinariaDataSet As VeterinariaDataSet
    Friend WithEvents VacunaBindingSource As BindingSource
    Friend WithEvents VacunaTableAdapter As VeterinariaDataSetTableAdapters.VacunaTableAdapter
    Friend WithEvents TableAdapterManager As VeterinariaDataSetTableAdapters.TableAdapterManager
    Friend WithEvents VacunaDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents CodVacunaTextBox As TextBox
    Friend WithEvents FechaTextBox As TextBox
    Friend WithEvents NumeroVacunaTextBox As TextBox
    Friend WithEvents DescripcionTextBox As TextBox
    Friend WithEvents IdMascotaTextBox As TextBox
    Friend WithEvents IdClienteTextBox As TextBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents LimpiarVacuna As Button
    Friend WithEvents EliminarVacuna As Button
    Friend WithEvents ModificarVAcuna As Button
    Friend WithEvents BuscarVacuna As Button
    Friend WithEvents MostrarVAcuna As Button
    Friend WithEvents AgregarVacuna As Button
End Class
