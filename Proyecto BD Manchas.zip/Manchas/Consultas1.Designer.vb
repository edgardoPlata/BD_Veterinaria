﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Consultas1
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim FechaLabel As System.Windows.Forms.Label
        Dim IdClienteLabel As System.Windows.Forms.Label
        Dim CodPagoLabel As System.Windows.Forms.Label
        Dim NumeroFacturaLabel As System.Windows.Forms.Label
        Dim FechaLabel1 As System.Windows.Forms.Label
        Dim IdProveedorLabel As System.Windows.Forms.Label
        Dim IdMedicinaLabel As System.Windows.Forms.Label
        Me.TabPage3 = New System.Windows.Forms.TabPage()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.ClienteDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ClienteBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VeterinariaDataSet = New Manchas.VeterinariaDataSet()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.LimpiarPago = New System.Windows.Forms.Button()
        Me.BuscarPago = New System.Windows.Forms.Button()
        Me.EliminarPago = New System.Windows.Forms.Button()
        Me.MostrarPAgo = New System.Windows.Forms.Button()
        Me.ModificarPago = New System.Windows.Forms.Button()
        Me.AgregarPago = New System.Windows.Forms.Button()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.PagoDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PagoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CodPagoTextBox = New System.Windows.Forms.TextBox()
        Me.IdClientePago = New System.Windows.Forms.TextBox()
        Me.FechaPago = New System.Windows.Forms.TextBox()
        Me.Pago = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.GroupBox9 = New System.Windows.Forms.GroupBox()
        Me.MedicinaDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MedicinaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GroupBox8 = New System.Windows.Forms.GroupBox()
        Me.ProveedorDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ProveedorBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GroupBox6 = New System.Windows.Forms.GroupBox()
        Me.FacturaDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.FacturaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.LimpiarFactura = New System.Windows.Forms.Button()
        Me.EliminarFactura = New System.Windows.Forms.Button()
        Me.ModificarFactura = New System.Windows.Forms.Button()
        Me.BuscarFactura = New System.Windows.Forms.Button()
        Me.MostrarFactura = New System.Windows.Forms.Button()
        Me.AgregarFactura = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.NumeroFacturaTextBox = New System.Windows.Forms.TextBox()
        Me.FechaFactura = New System.Windows.Forms.TextBox()
        Me.IdProveedorTextBox = New System.Windows.Forms.TextBox()
        Me.IdMedicinaTextBox = New System.Windows.Forms.TextBox()
        Me.PagoTableAdapter = New Manchas.VeterinariaDataSetTableAdapters.PagoTableAdapter()
        Me.TableAdapterManager = New Manchas.VeterinariaDataSetTableAdapters.TableAdapterManager()
        Me.FacturaTableAdapter = New Manchas.VeterinariaDataSetTableAdapters.FacturaTableAdapter()
        Me.ClienteTableAdapter = New Manchas.VeterinariaDataSetTableAdapters.ClienteTableAdapter()
        Me.ProveedorTableAdapter = New Manchas.VeterinariaDataSetTableAdapters.ProveedorTableAdapter()
        Me.MedicinaTableAdapter = New Manchas.VeterinariaDataSetTableAdapters.MedicinaTableAdapter()
        FechaLabel = New System.Windows.Forms.Label()
        IdClienteLabel = New System.Windows.Forms.Label()
        CodPagoLabel = New System.Windows.Forms.Label()
        NumeroFacturaLabel = New System.Windows.Forms.Label()
        FechaLabel1 = New System.Windows.Forms.Label()
        IdProveedorLabel = New System.Windows.Forms.Label()
        IdMedicinaLabel = New System.Windows.Forms.Label()
        Me.TabPage3.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        CType(Me.ClienteDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ClienteBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VeterinariaDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PagoDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PagoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        Me.Pago.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.GroupBox9.SuspendLayout()
        CType(Me.MedicinaDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MedicinaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox8.SuspendLayout()
        CType(Me.ProveedorDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ProveedorBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox6.SuspendLayout()
        CType(Me.FacturaDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.FacturaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.SuspendLayout()
        '
        'FechaLabel
        '
        FechaLabel.AutoSize = True
        FechaLabel.Location = New System.Drawing.Point(24, 78)
        FechaLabel.Name = "FechaLabel"
        FechaLabel.Size = New System.Drawing.Size(74, 24)
        FechaLabel.TabIndex = 2
        FechaLabel.Text = "Fecha:"
        '
        'IdClienteLabel
        '
        IdClienteLabel.AutoSize = True
        IdClienteLabel.Location = New System.Drawing.Point(24, 114)
        IdClienteLabel.Name = "IdClienteLabel"
        IdClienteLabel.Size = New System.Drawing.Size(105, 24)
        IdClienteLabel.TabIndex = 4
        IdClienteLabel.Text = "Id Cliente:"
        '
        'CodPagoLabel
        '
        CodPagoLabel.AutoSize = True
        CodPagoLabel.Location = New System.Drawing.Point(24, 42)
        CodPagoLabel.Name = "CodPagoLabel"
        CodPagoLabel.Size = New System.Drawing.Size(109, 24)
        CodPagoLabel.TabIndex = 0
        CodPagoLabel.Text = "Cod Pago:"
        '
        'NumeroFacturaLabel
        '
        NumeroFacturaLabel.AutoSize = True
        NumeroFacturaLabel.Location = New System.Drawing.Point(8, 43)
        NumeroFacturaLabel.Name = "NumeroFacturaLabel"
        NumeroFacturaLabel.Size = New System.Drawing.Size(169, 24)
        NumeroFacturaLabel.TabIndex = 0
        NumeroFacturaLabel.Text = "Numero Factura:"
        '
        'FechaLabel1
        '
        FechaLabel1.AutoSize = True
        FechaLabel1.Location = New System.Drawing.Point(8, 79)
        FechaLabel1.Name = "FechaLabel1"
        FechaLabel1.Size = New System.Drawing.Size(74, 24)
        FechaLabel1.TabIndex = 2
        FechaLabel1.Text = "Fecha:"
        '
        'IdProveedorLabel
        '
        IdProveedorLabel.AutoSize = True
        IdProveedorLabel.Location = New System.Drawing.Point(8, 115)
        IdProveedorLabel.Name = "IdProveedorLabel"
        IdProveedorLabel.Size = New System.Drawing.Size(138, 24)
        IdProveedorLabel.TabIndex = 4
        IdProveedorLabel.Text = "Id Proveedor:"
        '
        'IdMedicinaLabel
        '
        IdMedicinaLabel.AutoSize = True
        IdMedicinaLabel.Location = New System.Drawing.Point(8, 151)
        IdMedicinaLabel.Name = "IdMedicinaLabel"
        IdMedicinaLabel.Size = New System.Drawing.Size(124, 24)
        IdMedicinaLabel.TabIndex = 6
        IdMedicinaLabel.Text = "Id Medicina:"
        '
        'TabPage3
        '
        Me.TabPage3.AutoScroll = True
        Me.TabPage3.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TabPage3.Controls.Add(Me.GroupBox7)
        Me.TabPage3.Controls.Add(Me.GroupBox3)
        Me.TabPage3.Controls.Add(Me.GroupBox2)
        Me.TabPage3.Controls.Add(Me.GroupBox1)
        Me.TabPage3.Location = New System.Drawing.Point(4, 33)
        Me.TabPage3.Name = "TabPage3"
        Me.TabPage3.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage3.Size = New System.Drawing.Size(1192, 601)
        Me.TabPage3.TabIndex = 2
        Me.TabPage3.Text = "Pago"
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.ClienteDataGridView)
        Me.GroupBox7.Location = New System.Drawing.Point(15, 313)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(1169, 257)
        Me.GroupBox7.TabIndex = 9
        Me.GroupBox7.TabStop = False
        Me.GroupBox7.Text = "Datos Cliente"
        '
        'ClienteDataGridView
        '
        Me.ClienteDataGridView.AutoGenerateColumns = False
        Me.ClienteDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ClienteDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13})
        Me.ClienteDataGridView.DataSource = Me.ClienteBindingSource
        Me.ClienteDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ClienteDataGridView.Location = New System.Drawing.Point(3, 26)
        Me.ClienteDataGridView.Name = "ClienteDataGridView"
        Me.ClienteDataGridView.RowHeadersWidth = 51
        Me.ClienteDataGridView.RowTemplate.Height = 24
        Me.ClienteDataGridView.Size = New System.Drawing.Size(1163, 228)
        Me.ClienteDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "CodCliente"
        Me.DataGridViewTextBoxColumn8.HeaderText = "CodCliente"
        Me.DataGridViewTextBoxColumn8.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.Width = 125
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "Nombre"
        Me.DataGridViewTextBoxColumn9.HeaderText = "Nombre"
        Me.DataGridViewTextBoxColumn9.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.Width = 125
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "Apellido"
        Me.DataGridViewTextBoxColumn10.HeaderText = "Apellido"
        Me.DataGridViewTextBoxColumn10.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.Width = 125
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.DataPropertyName = "Cedula"
        Me.DataGridViewTextBoxColumn11.HeaderText = "Cedula"
        Me.DataGridViewTextBoxColumn11.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.Width = 125
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.DataPropertyName = "Direccion"
        Me.DataGridViewTextBoxColumn12.HeaderText = "Direccion"
        Me.DataGridViewTextBoxColumn12.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.Width = 125
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.DataPropertyName = "Telefono"
        Me.DataGridViewTextBoxColumn13.HeaderText = "Telefono"
        Me.DataGridViewTextBoxColumn13.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.Width = 125
        '
        'ClienteBindingSource
        '
        Me.ClienteBindingSource.DataMember = "Cliente"
        Me.ClienteBindingSource.DataSource = Me.VeterinariaDataSet
        '
        'VeterinariaDataSet
        '
        Me.VeterinariaDataSet.DataSetName = "VeterinariaDataSet"
        Me.VeterinariaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LimpiarPago)
        Me.GroupBox3.Controls.Add(Me.BuscarPago)
        Me.GroupBox3.Controls.Add(Me.EliminarPago)
        Me.GroupBox3.Controls.Add(Me.MostrarPAgo)
        Me.GroupBox3.Controls.Add(Me.ModificarPago)
        Me.GroupBox3.Controls.Add(Me.AgregarPago)
        Me.GroupBox3.Location = New System.Drawing.Point(8, 180)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(390, 118)
        Me.GroupBox3.TabIndex = 8
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Opciones"
        '
        'LimpiarPago
        '
        Me.LimpiarPago.Location = New System.Drawing.Point(267, 72)
        Me.LimpiarPago.Name = "LimpiarPago"
        Me.LimpiarPago.Size = New System.Drawing.Size(111, 36)
        Me.LimpiarPago.TabIndex = 11
        Me.LimpiarPago.Text = "Limpiar"
        Me.LimpiarPago.UseVisualStyleBackColor = True
        '
        'BuscarPago
        '
        Me.BuscarPago.Location = New System.Drawing.Point(267, 30)
        Me.BuscarPago.Name = "BuscarPago"
        Me.BuscarPago.Size = New System.Drawing.Size(111, 36)
        Me.BuscarPago.TabIndex = 2
        Me.BuscarPago.Text = "Buscar"
        Me.BuscarPago.UseVisualStyleBackColor = True
        '
        'EliminarPago
        '
        Me.EliminarPago.Location = New System.Drawing.Point(138, 72)
        Me.EliminarPago.Name = "EliminarPago"
        Me.EliminarPago.Size = New System.Drawing.Size(111, 36)
        Me.EliminarPago.TabIndex = 10
        Me.EliminarPago.Text = "Eliminar"
        Me.EliminarPago.UseVisualStyleBackColor = True
        '
        'MostrarPAgo
        '
        Me.MostrarPAgo.Location = New System.Drawing.Point(138, 30)
        Me.MostrarPAgo.Name = "MostrarPAgo"
        Me.MostrarPAgo.Size = New System.Drawing.Size(111, 36)
        Me.MostrarPAgo.TabIndex = 1
        Me.MostrarPAgo.Text = "Mostrar"
        Me.MostrarPAgo.UseVisualStyleBackColor = True
        '
        'ModificarPago
        '
        Me.ModificarPago.Location = New System.Drawing.Point(7, 72)
        Me.ModificarPago.Name = "ModificarPago"
        Me.ModificarPago.Size = New System.Drawing.Size(111, 36)
        Me.ModificarPago.TabIndex = 9
        Me.ModificarPago.Text = "Modificar"
        Me.ModificarPago.UseVisualStyleBackColor = True
        '
        'AgregarPago
        '
        Me.AgregarPago.Location = New System.Drawing.Point(7, 30)
        Me.AgregarPago.Name = "AgregarPago"
        Me.AgregarPago.Size = New System.Drawing.Size(111, 36)
        Me.AgregarPago.TabIndex = 0
        Me.AgregarPago.Text = "Agregar"
        Me.AgregarPago.UseVisualStyleBackColor = True
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.PagoDataGridView)
        Me.GroupBox2.Location = New System.Drawing.Point(404, 18)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(538, 280)
        Me.GroupBox2.TabIndex = 7
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Datos Pago"
        '
        'PagoDataGridView
        '
        Me.PagoDataGridView.AutoGenerateColumns = False
        Me.PagoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.PagoDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3})
        Me.PagoDataGridView.DataSource = Me.PagoBindingSource
        Me.PagoDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.PagoDataGridView.Location = New System.Drawing.Point(3, 26)
        Me.PagoDataGridView.Name = "PagoDataGridView"
        Me.PagoDataGridView.RowHeadersWidth = 51
        Me.PagoDataGridView.RowTemplate.Height = 24
        Me.PagoDataGridView.Size = New System.Drawing.Size(532, 251)
        Me.PagoDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "CodPago"
        Me.DataGridViewTextBoxColumn1.HeaderText = "CodPago"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 125
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Fecha"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Fecha"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 125
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "IdCliente"
        Me.DataGridViewTextBoxColumn3.HeaderText = "IdCliente"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 125
        '
        'PagoBindingSource
        '
        Me.PagoBindingSource.DataMember = "Pago"
        Me.PagoBindingSource.DataSource = Me.VeterinariaDataSet
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.CodPagoTextBox)
        Me.GroupBox1.Controls.Add(CodPagoLabel)
        Me.GroupBox1.Controls.Add(Me.IdClientePago)
        Me.GroupBox1.Controls.Add(IdClienteLabel)
        Me.GroupBox1.Controls.Add(FechaLabel)
        Me.GroupBox1.Controls.Add(Me.FechaPago)
        Me.GroupBox1.Location = New System.Drawing.Point(8, 18)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(390, 153)
        Me.GroupBox1.TabIndex = 6
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Pago"
        '
        'CodPagoTextBox
        '
        Me.CodPagoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PagoBindingSource, "CodPago", True))
        Me.CodPagoTextBox.Location = New System.Drawing.Point(164, 39)
        Me.CodPagoTextBox.Name = "CodPagoTextBox"
        Me.CodPagoTextBox.Size = New System.Drawing.Size(175, 30)
        Me.CodPagoTextBox.TabIndex = 1
        '
        'IdClientePago
        '
        Me.IdClientePago.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PagoBindingSource, "IdCliente", True))
        Me.IdClientePago.Location = New System.Drawing.Point(164, 111)
        Me.IdClientePago.Name = "IdClientePago"
        Me.IdClientePago.Size = New System.Drawing.Size(175, 30)
        Me.IdClientePago.TabIndex = 5
        '
        'FechaPago
        '
        Me.FechaPago.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PagoBindingSource, "Fecha", True))
        Me.FechaPago.Location = New System.Drawing.Point(164, 75)
        Me.FechaPago.Name = "FechaPago"
        Me.FechaPago.Size = New System.Drawing.Size(175, 30)
        Me.FechaPago.TabIndex = 3
        '
        'Pago
        '
        Me.Pago.Controls.Add(Me.TabPage3)
        Me.Pago.Controls.Add(Me.TabPage1)
        Me.Pago.Dock = System.Windows.Forms.DockStyle.Fill
        Me.Pago.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Pago.Location = New System.Drawing.Point(0, 0)
        Me.Pago.Name = "Pago"
        Me.Pago.SelectedIndex = 0
        Me.Pago.Size = New System.Drawing.Size(1200, 638)
        Me.Pago.TabIndex = 0
        '
        'TabPage1
        '
        Me.TabPage1.AutoScroll = True
        Me.TabPage1.BackColor = System.Drawing.Color.IndianRed
        Me.TabPage1.Controls.Add(Me.GroupBox9)
        Me.TabPage1.Controls.Add(Me.GroupBox8)
        Me.TabPage1.Controls.Add(Me.GroupBox6)
        Me.TabPage1.Controls.Add(Me.GroupBox5)
        Me.TabPage1.Controls.Add(Me.GroupBox4)
        Me.TabPage1.Location = New System.Drawing.Point(4, 33)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(1192, 601)
        Me.TabPage1.TabIndex = 3
        Me.TabPage1.Text = "Factura"
        '
        'GroupBox9
        '
        Me.GroupBox9.Controls.Add(Me.MedicinaDataGridView)
        Me.GroupBox9.Location = New System.Drawing.Point(643, 381)
        Me.GroupBox9.Name = "GroupBox9"
        Me.GroupBox9.Size = New System.Drawing.Size(488, 180)
        Me.GroupBox9.TabIndex = 4
        Me.GroupBox9.TabStop = False
        Me.GroupBox9.Text = "Datos Medicina"
        '
        'MedicinaDataGridView
        '
        Me.MedicinaDataGridView.AutoGenerateColumns = False
        Me.MedicinaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.MedicinaDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn19, Me.DataGridViewTextBoxColumn20, Me.DataGridViewTextBoxColumn21, Me.DataGridViewTextBoxColumn22})
        Me.MedicinaDataGridView.DataSource = Me.MedicinaBindingSource
        Me.MedicinaDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MedicinaDataGridView.Location = New System.Drawing.Point(3, 26)
        Me.MedicinaDataGridView.Name = "MedicinaDataGridView"
        Me.MedicinaDataGridView.RowHeadersWidth = 51
        Me.MedicinaDataGridView.RowTemplate.Height = 24
        Me.MedicinaDataGridView.Size = New System.Drawing.Size(482, 151)
        Me.MedicinaDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.DataPropertyName = "CodMedicina"
        Me.DataGridViewTextBoxColumn19.HeaderText = "CodMedicina"
        Me.DataGridViewTextBoxColumn19.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        Me.DataGridViewTextBoxColumn19.Width = 125
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.DataPropertyName = "Nombre"
        Me.DataGridViewTextBoxColumn20.HeaderText = "Nombre"
        Me.DataGridViewTextBoxColumn20.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        Me.DataGridViewTextBoxColumn20.Width = 125
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.DataPropertyName = "Precio"
        Me.DataGridViewTextBoxColumn21.HeaderText = "Precio"
        Me.DataGridViewTextBoxColumn21.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        Me.DataGridViewTextBoxColumn21.Width = 125
        '
        'DataGridViewTextBoxColumn22
        '
        Me.DataGridViewTextBoxColumn22.DataPropertyName = "fechaVencimeinto"
        Me.DataGridViewTextBoxColumn22.HeaderText = "fechaVencimeinto"
        Me.DataGridViewTextBoxColumn22.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        Me.DataGridViewTextBoxColumn22.Width = 125
        '
        'MedicinaBindingSource
        '
        Me.MedicinaBindingSource.DataMember = "Medicina"
        Me.MedicinaBindingSource.DataSource = Me.VeterinariaDataSet
        '
        'GroupBox8
        '
        Me.GroupBox8.Controls.Add(Me.ProveedorDataGridView)
        Me.GroupBox8.Location = New System.Drawing.Point(20, 381)
        Me.GroupBox8.Name = "GroupBox8"
        Me.GroupBox8.Size = New System.Drawing.Size(617, 183)
        Me.GroupBox8.TabIndex = 3
        Me.GroupBox8.TabStop = False
        Me.GroupBox8.Text = "Datos Proveedor"
        '
        'ProveedorDataGridView
        '
        Me.ProveedorDataGridView.AutoGenerateColumns = False
        Me.ProveedorDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ProveedorDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18})
        Me.ProveedorDataGridView.DataSource = Me.ProveedorBindingSource
        Me.ProveedorDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ProveedorDataGridView.Location = New System.Drawing.Point(3, 26)
        Me.ProveedorDataGridView.Name = "ProveedorDataGridView"
        Me.ProveedorDataGridView.RowHeadersWidth = 51
        Me.ProveedorDataGridView.RowTemplate.Height = 24
        Me.ProveedorDataGridView.Size = New System.Drawing.Size(611, 154)
        Me.ProveedorDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.DataPropertyName = "CodProveedor"
        Me.DataGridViewTextBoxColumn14.HeaderText = "CodProveedor"
        Me.DataGridViewTextBoxColumn14.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        Me.DataGridViewTextBoxColumn14.Width = 125
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.DataPropertyName = "Nombre"
        Me.DataGridViewTextBoxColumn15.HeaderText = "Nombre"
        Me.DataGridViewTextBoxColumn15.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        Me.DataGridViewTextBoxColumn15.Width = 125
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.DataPropertyName = "Apellido"
        Me.DataGridViewTextBoxColumn16.HeaderText = "Apellido"
        Me.DataGridViewTextBoxColumn16.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        Me.DataGridViewTextBoxColumn16.Width = 125
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.DataPropertyName = "Direccion"
        Me.DataGridViewTextBoxColumn17.HeaderText = "Direccion"
        Me.DataGridViewTextBoxColumn17.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        Me.DataGridViewTextBoxColumn17.Width = 125
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.DataPropertyName = "Telefono"
        Me.DataGridViewTextBoxColumn18.HeaderText = "Telefono"
        Me.DataGridViewTextBoxColumn18.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        Me.DataGridViewTextBoxColumn18.Width = 125
        '
        'ProveedorBindingSource
        '
        Me.ProveedorBindingSource.DataMember = "Proveedor"
        Me.ProveedorBindingSource.DataSource = Me.VeterinariaDataSet
        '
        'GroupBox6
        '
        Me.GroupBox6.Controls.Add(Me.FacturaDataGridView)
        Me.GroupBox6.Location = New System.Drawing.Point(454, 16)
        Me.GroupBox6.Name = "GroupBox6"
        Me.GroupBox6.Size = New System.Drawing.Size(680, 328)
        Me.GroupBox6.TabIndex = 2
        Me.GroupBox6.TabStop = False
        Me.GroupBox6.Text = "Datos Factura"
        '
        'FacturaDataGridView
        '
        Me.FacturaDataGridView.AutoGenerateColumns = False
        Me.FacturaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.FacturaDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7})
        Me.FacturaDataGridView.DataSource = Me.FacturaBindingSource
        Me.FacturaDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.FacturaDataGridView.Location = New System.Drawing.Point(3, 26)
        Me.FacturaDataGridView.Name = "FacturaDataGridView"
        Me.FacturaDataGridView.RowHeadersWidth = 51
        Me.FacturaDataGridView.RowTemplate.Height = 24
        Me.FacturaDataGridView.Size = New System.Drawing.Size(674, 299)
        Me.FacturaDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "NumeroFactura"
        Me.DataGridViewTextBoxColumn4.HeaderText = "NumeroFactura"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 125
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "Fecha"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Fecha"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Width = 125
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "IdProveedor"
        Me.DataGridViewTextBoxColumn6.HeaderText = "IdProveedor"
        Me.DataGridViewTextBoxColumn6.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Width = 125
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "IdMedicina"
        Me.DataGridViewTextBoxColumn7.HeaderText = "IdMedicina"
        Me.DataGridViewTextBoxColumn7.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.Width = 125
        '
        'FacturaBindingSource
        '
        Me.FacturaBindingSource.DataMember = "Factura"
        Me.FacturaBindingSource.DataSource = Me.VeterinariaDataSet
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.LimpiarFactura)
        Me.GroupBox5.Controls.Add(Me.EliminarFactura)
        Me.GroupBox5.Controls.Add(Me.ModificarFactura)
        Me.GroupBox5.Controls.Add(Me.BuscarFactura)
        Me.GroupBox5.Controls.Add(Me.MostrarFactura)
        Me.GroupBox5.Controls.Add(Me.AgregarFactura)
        Me.GroupBox5.Location = New System.Drawing.Point(8, 217)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(386, 127)
        Me.GroupBox5.TabIndex = 1
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Opciones"
        '
        'LimpiarFactura
        '
        Me.LimpiarFactura.Location = New System.Drawing.Point(258, 79)
        Me.LimpiarFactura.Name = "LimpiarFactura"
        Me.LimpiarFactura.Size = New System.Drawing.Size(120, 34)
        Me.LimpiarFactura.TabIndex = 5
        Me.LimpiarFactura.Text = "Limpiar"
        Me.LimpiarFactura.UseVisualStyleBackColor = True
        '
        'EliminarFactura
        '
        Me.EliminarFactura.Location = New System.Drawing.Point(132, 79)
        Me.EliminarFactura.Name = "EliminarFactura"
        Me.EliminarFactura.Size = New System.Drawing.Size(120, 34)
        Me.EliminarFactura.TabIndex = 4
        Me.EliminarFactura.Text = "Eliminar"
        Me.EliminarFactura.UseVisualStyleBackColor = True
        '
        'ModificarFactura
        '
        Me.ModificarFactura.Location = New System.Drawing.Point(6, 79)
        Me.ModificarFactura.Name = "ModificarFactura"
        Me.ModificarFactura.Size = New System.Drawing.Size(120, 34)
        Me.ModificarFactura.TabIndex = 3
        Me.ModificarFactura.Text = "Modificar"
        Me.ModificarFactura.UseVisualStyleBackColor = True
        '
        'BuscarFactura
        '
        Me.BuscarFactura.Location = New System.Drawing.Point(258, 39)
        Me.BuscarFactura.Name = "BuscarFactura"
        Me.BuscarFactura.Size = New System.Drawing.Size(120, 34)
        Me.BuscarFactura.TabIndex = 2
        Me.BuscarFactura.Text = "Buscar"
        Me.BuscarFactura.UseVisualStyleBackColor = True
        '
        'MostrarFactura
        '
        Me.MostrarFactura.Location = New System.Drawing.Point(132, 39)
        Me.MostrarFactura.Name = "MostrarFactura"
        Me.MostrarFactura.Size = New System.Drawing.Size(120, 34)
        Me.MostrarFactura.TabIndex = 1
        Me.MostrarFactura.Text = "Mostrar"
        Me.MostrarFactura.UseVisualStyleBackColor = True
        '
        'AgregarFactura
        '
        Me.AgregarFactura.Location = New System.Drawing.Point(6, 39)
        Me.AgregarFactura.Name = "AgregarFactura"
        Me.AgregarFactura.Size = New System.Drawing.Size(120, 34)
        Me.AgregarFactura.TabIndex = 0
        Me.AgregarFactura.Text = "Agregar"
        Me.AgregarFactura.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(NumeroFacturaLabel)
        Me.GroupBox4.Controls.Add(Me.NumeroFacturaTextBox)
        Me.GroupBox4.Controls.Add(FechaLabel1)
        Me.GroupBox4.Controls.Add(Me.FechaFactura)
        Me.GroupBox4.Controls.Add(IdProveedorLabel)
        Me.GroupBox4.Controls.Add(Me.IdProveedorTextBox)
        Me.GroupBox4.Controls.Add(IdMedicinaLabel)
        Me.GroupBox4.Controls.Add(Me.IdMedicinaTextBox)
        Me.GroupBox4.Location = New System.Drawing.Point(8, 16)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(386, 195)
        Me.GroupBox4.TabIndex = 0
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Factura"
        '
        'NumeroFacturaTextBox
        '
        Me.NumeroFacturaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.FacturaBindingSource, "NumeroFactura", True))
        Me.NumeroFacturaTextBox.Location = New System.Drawing.Point(197, 43)
        Me.NumeroFacturaTextBox.Name = "NumeroFacturaTextBox"
        Me.NumeroFacturaTextBox.Size = New System.Drawing.Size(174, 30)
        Me.NumeroFacturaTextBox.TabIndex = 1
        '
        'FechaFactura
        '
        Me.FechaFactura.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.FacturaBindingSource, "Fecha", True))
        Me.FechaFactura.Location = New System.Drawing.Point(197, 79)
        Me.FechaFactura.Name = "FechaFactura"
        Me.FechaFactura.Size = New System.Drawing.Size(174, 30)
        Me.FechaFactura.TabIndex = 3
        '
        'IdProveedorTextBox
        '
        Me.IdProveedorTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.FacturaBindingSource, "IdProveedor", True))
        Me.IdProveedorTextBox.Location = New System.Drawing.Point(197, 115)
        Me.IdProveedorTextBox.Name = "IdProveedorTextBox"
        Me.IdProveedorTextBox.Size = New System.Drawing.Size(174, 30)
        Me.IdProveedorTextBox.TabIndex = 5
        '
        'IdMedicinaTextBox
        '
        Me.IdMedicinaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.FacturaBindingSource, "IdMedicina", True))
        Me.IdMedicinaTextBox.Location = New System.Drawing.Point(197, 151)
        Me.IdMedicinaTextBox.Name = "IdMedicinaTextBox"
        Me.IdMedicinaTextBox.Size = New System.Drawing.Size(174, 30)
        Me.IdMedicinaTextBox.TabIndex = 7
        '
        'PagoTableAdapter
        '
        Me.PagoTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CategoriaTableAdapter = Nothing
        Me.TableAdapterManager.ClienteTableAdapter = Nothing
        Me.TableAdapterManager.DetalleFacturaTableAdapter = Nothing
        Me.TableAdapterManager.DetallePagoTableAdapter = Nothing
        Me.TableAdapterManager.FacturaTableAdapter = Me.FacturaTableAdapter
        Me.TableAdapterManager.MascotaTableAdapter = Nothing
        Me.TableAdapterManager.MedicinaTableAdapter = Nothing
        Me.TableAdapterManager.PagoTableAdapter = Me.PagoTableAdapter
        Me.TableAdapterManager.ProductoTableAdapter = Nothing
        Me.TableAdapterManager.ProveedorTableAdapter = Nothing
        Me.TableAdapterManager.ServicioTableAdapter = Nothing
        Me.TableAdapterManager.TipoTableAdapter = Nothing
        Me.TableAdapterManager.TratamientoTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Manchas.VeterinariaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.VacunaTableAdapter = Nothing
        '
        'FacturaTableAdapter
        '
        Me.FacturaTableAdapter.ClearBeforeFill = True
        '
        'ClienteTableAdapter
        '
        Me.ClienteTableAdapter.ClearBeforeFill = True
        '
        'ProveedorTableAdapter
        '
        Me.ProveedorTableAdapter.ClearBeforeFill = True
        '
        'MedicinaTableAdapter
        '
        Me.MedicinaTableAdapter.ClearBeforeFill = True
        '
        'Consultas1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoValidate = System.Windows.Forms.AutoValidate.EnablePreventFocusChange
        Me.ClientSize = New System.Drawing.Size(1200, 638)
        Me.Controls.Add(Me.Pago)
        Me.Name = "Consultas1"
        Me.Text = "Consultas1"
        Me.TabPage3.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        CType(Me.ClienteDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ClienteBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VeterinariaDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.PagoDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PagoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.Pago.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.GroupBox9.ResumeLayout(False)
        CType(Me.MedicinaDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MedicinaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox8.ResumeLayout(False)
        CType(Me.ProveedorDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ProveedorBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox6.ResumeLayout(False)
        CType(Me.FacturaDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.FacturaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents VeterinariaDataSet As VeterinariaDataSet
    Friend WithEvents PagoBindingSource As BindingSource
    Friend WithEvents PagoTableAdapter As VeterinariaDataSetTableAdapters.PagoTableAdapter
    Friend WithEvents TableAdapterManager As VeterinariaDataSetTableAdapters.TableAdapterManager
    Friend WithEvents TabPage3 As TabPage
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents LimpiarPago As Button
    Friend WithEvents BuscarPago As Button
    Friend WithEvents EliminarPago As Button
    Friend WithEvents MostrarPAgo As Button
    Friend WithEvents ModificarPago As Button
    Friend WithEvents AgregarPago As Button
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents PagoDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents CodPagoTextBox As TextBox
    Friend WithEvents IdClientePago As TextBox
    Friend WithEvents FechaPago As TextBox
    Friend WithEvents Pago As TabControl
    Friend WithEvents FacturaTableAdapter As VeterinariaDataSetTableAdapters.FacturaTableAdapter
    Friend WithEvents TabPage1 As TabPage
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents FacturaBindingSource As BindingSource
    Friend WithEvents NumeroFacturaTextBox As TextBox
    Friend WithEvents FechaFactura As TextBox
    Friend WithEvents IdProveedorTextBox As TextBox
    Friend WithEvents IdMedicinaTextBox As TextBox
    Friend WithEvents GroupBox6 As GroupBox
    Friend WithEvents FacturaDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents LimpiarFactura As Button
    Friend WithEvents EliminarFactura As Button
    Friend WithEvents ModificarFactura As Button
    Friend WithEvents BuscarFactura As Button
    Friend WithEvents MostrarFactura As Button
    Friend WithEvents AgregarFactura As Button
    Friend WithEvents GroupBox7 As GroupBox
    Friend WithEvents ClienteBindingSource As BindingSource
    Friend WithEvents ClienteTableAdapter As VeterinariaDataSetTableAdapters.ClienteTableAdapter
    Friend WithEvents ClienteDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
    Friend WithEvents GroupBox8 As GroupBox
    Friend WithEvents ProveedorBindingSource As BindingSource
    Friend WithEvents ProveedorTableAdapter As VeterinariaDataSetTableAdapters.ProveedorTableAdapter
    Friend WithEvents GroupBox9 As GroupBox
    Friend WithEvents ProveedorDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn14 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As DataGridViewTextBoxColumn
    Friend WithEvents MedicinaBindingSource As BindingSource
    Friend WithEvents MedicinaTableAdapter As VeterinariaDataSetTableAdapters.MedicinaTableAdapter
    Friend WithEvents MedicinaDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn19 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn20 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn21 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn22 As DataGridViewTextBoxColumn
End Class
