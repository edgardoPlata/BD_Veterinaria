﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Tratamiento
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim CodTratamientoLabel As System.Windows.Forms.Label
        Dim TratamientoLabel As System.Windows.Forms.Label
        Dim DescripcionLabel As System.Windows.Forms.Label
        Dim CostoLabel As System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CodTratamientoTextBox = New System.Windows.Forms.TextBox()
        Me.TratamientoBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VeterinariaDataSet = New Manchas.VeterinariaDataSet()
        Me.TratamientoTextBox = New System.Windows.Forms.TextBox()
        Me.DescripcionTextBox = New System.Windows.Forms.TextBox()
        Me.CostoTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.TratamientoDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.LimpiarTrtamiento = New System.Windows.Forms.Button()
        Me.ModificarTratamiento = New System.Windows.Forms.Button()
        Me.EliminarTratamiento = New System.Windows.Forms.Button()
        Me.BuscarTratamiento = New System.Windows.Forms.Button()
        Me.MostrarTratamiento = New System.Windows.Forms.Button()
        Me.AgregarTratamiento = New System.Windows.Forms.Button()
        Me.TratamientoTableAdapter = New Manchas.VeterinariaDataSetTableAdapters.TratamientoTableAdapter()
        Me.TableAdapterManager = New Manchas.VeterinariaDataSetTableAdapters.TableAdapterManager()
        CodTratamientoLabel = New System.Windows.Forms.Label()
        TratamientoLabel = New System.Windows.Forms.Label()
        DescripcionLabel = New System.Windows.Forms.Label()
        CostoLabel = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.TratamientoBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VeterinariaDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        CType(Me.TratamientoDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'CodTratamientoLabel
        '
        CodTratamientoLabel.AutoSize = True
        CodTratamientoLabel.Location = New System.Drawing.Point(19, 43)
        CodTratamientoLabel.Name = "CodTratamientoLabel"
        CodTratamientoLabel.Size = New System.Drawing.Size(174, 24)
        CodTratamientoLabel.TabIndex = 0
        CodTratamientoLabel.Text = "Cod Tratamiento:"
        '
        'TratamientoLabel
        '
        TratamientoLabel.AutoSize = True
        TratamientoLabel.Location = New System.Drawing.Point(19, 79)
        TratamientoLabel.Name = "TratamientoLabel"
        TratamientoLabel.Size = New System.Drawing.Size(130, 24)
        TratamientoLabel.TabIndex = 2
        TratamientoLabel.Text = "Tratamiento:"
        '
        'DescripcionLabel
        '
        DescripcionLabel.AutoSize = True
        DescripcionLabel.Location = New System.Drawing.Point(19, 115)
        DescripcionLabel.Name = "DescripcionLabel"
        DescripcionLabel.Size = New System.Drawing.Size(129, 24)
        DescripcionLabel.TabIndex = 4
        DescripcionLabel.Text = "Descripcion:"
        '
        'CostoLabel
        '
        CostoLabel.AutoSize = True
        CostoLabel.Location = New System.Drawing.Point(19, 151)
        CostoLabel.Name = "CostoLabel"
        CostoLabel.Size = New System.Drawing.Size(73, 24)
        CostoLabel.TabIndex = 6
        CostoLabel.Text = "Costo:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(CodTratamientoLabel)
        Me.GroupBox1.Controls.Add(Me.CodTratamientoTextBox)
        Me.GroupBox1.Controls.Add(TratamientoLabel)
        Me.GroupBox1.Controls.Add(Me.TratamientoTextBox)
        Me.GroupBox1.Controls.Add(DescripcionLabel)
        Me.GroupBox1.Controls.Add(Me.DescripcionTextBox)
        Me.GroupBox1.Controls.Add(CostoLabel)
        Me.GroupBox1.Controls.Add(Me.CostoTextBox)
        Me.GroupBox1.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(12, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(440, 185)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Tratamiento"
        '
        'CodTratamientoTextBox
        '
        Me.CodTratamientoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TratamientoBindingSource, "CodTratamiento", True))
        Me.CodTratamientoTextBox.Location = New System.Drawing.Point(233, 37)
        Me.CodTratamientoTextBox.Name = "CodTratamientoTextBox"
        Me.CodTratamientoTextBox.Size = New System.Drawing.Size(198, 30)
        Me.CodTratamientoTextBox.TabIndex = 1
        '
        'TratamientoBindingSource
        '
        Me.TratamientoBindingSource.DataMember = "Tratamiento"
        Me.TratamientoBindingSource.DataSource = Me.VeterinariaDataSet
        '
        'VeterinariaDataSet
        '
        Me.VeterinariaDataSet.DataSetName = "VeterinariaDataSet"
        Me.VeterinariaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TratamientoTextBox
        '
        Me.TratamientoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TratamientoBindingSource, "Tratamiento", True))
        Me.TratamientoTextBox.Location = New System.Drawing.Point(233, 73)
        Me.TratamientoTextBox.Name = "TratamientoTextBox"
        Me.TratamientoTextBox.Size = New System.Drawing.Size(198, 30)
        Me.TratamientoTextBox.TabIndex = 3
        '
        'DescripcionTextBox
        '
        Me.DescripcionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TratamientoBindingSource, "Descripcion", True))
        Me.DescripcionTextBox.Location = New System.Drawing.Point(233, 109)
        Me.DescripcionTextBox.Name = "DescripcionTextBox"
        Me.DescripcionTextBox.Size = New System.Drawing.Size(198, 30)
        Me.DescripcionTextBox.TabIndex = 5
        '
        'CostoTextBox
        '
        Me.CostoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TratamientoBindingSource, "Costo", True))
        Me.CostoTextBox.Location = New System.Drawing.Point(233, 145)
        Me.CostoTextBox.Name = "CostoTextBox"
        Me.CostoTextBox.Size = New System.Drawing.Size(198, 30)
        Me.CostoTextBox.TabIndex = 7
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.TratamientoDataGridView)
        Me.GroupBox2.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(475, 23)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(710, 363)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Datos Tratamiento"
        '
        'TratamientoDataGridView
        '
        Me.TratamientoDataGridView.AutoGenerateColumns = False
        Me.TratamientoDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TratamientoDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4})
        Me.TratamientoDataGridView.DataSource = Me.TratamientoBindingSource
        Me.TratamientoDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TratamientoDataGridView.Location = New System.Drawing.Point(3, 26)
        Me.TratamientoDataGridView.Name = "TratamientoDataGridView"
        Me.TratamientoDataGridView.RowHeadersWidth = 51
        Me.TratamientoDataGridView.RowTemplate.Height = 24
        Me.TratamientoDataGridView.Size = New System.Drawing.Size(704, 334)
        Me.TratamientoDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "CodTratamiento"
        Me.DataGridViewTextBoxColumn1.HeaderText = "CodTratamiento"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 125
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Tratamiento"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Tratamiento"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 125
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Descripcion"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Descripcion"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 125
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "Costo"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Costo"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 125
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.LimpiarTrtamiento)
        Me.GroupBox3.Controls.Add(Me.ModificarTratamiento)
        Me.GroupBox3.Controls.Add(Me.EliminarTratamiento)
        Me.GroupBox3.Controls.Add(Me.BuscarTratamiento)
        Me.GroupBox3.Controls.Add(Me.MostrarTratamiento)
        Me.GroupBox3.Controls.Add(Me.AgregarTratamiento)
        Me.GroupBox3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(12, 215)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(440, 141)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Opciones"
        '
        'LimpiarTrtamiento
        '
        Me.LimpiarTrtamiento.Location = New System.Drawing.Point(278, 90)
        Me.LimpiarTrtamiento.Name = "LimpiarTrtamiento"
        Me.LimpiarTrtamiento.Size = New System.Drawing.Size(106, 38)
        Me.LimpiarTrtamiento.TabIndex = 8
        Me.LimpiarTrtamiento.Text = "Limpiar"
        Me.LimpiarTrtamiento.UseVisualStyleBackColor = True
        '
        'ModificarTratamiento
        '
        Me.ModificarTratamiento.Location = New System.Drawing.Point(278, 45)
        Me.ModificarTratamiento.Name = "ModificarTratamiento"
        Me.ModificarTratamiento.Size = New System.Drawing.Size(106, 38)
        Me.ModificarTratamiento.TabIndex = 5
        Me.ModificarTratamiento.Text = "Modificar"
        Me.ModificarTratamiento.UseVisualStyleBackColor = True
        '
        'EliminarTratamiento
        '
        Me.EliminarTratamiento.Location = New System.Drawing.Point(149, 90)
        Me.EliminarTratamiento.Name = "EliminarTratamiento"
        Me.EliminarTratamiento.Size = New System.Drawing.Size(106, 38)
        Me.EliminarTratamiento.TabIndex = 7
        Me.EliminarTratamiento.Text = "Eliminar"
        Me.EliminarTratamiento.UseVisualStyleBackColor = True
        '
        'BuscarTratamiento
        '
        Me.BuscarTratamiento.Location = New System.Drawing.Point(149, 45)
        Me.BuscarTratamiento.Name = "BuscarTratamiento"
        Me.BuscarTratamiento.Size = New System.Drawing.Size(106, 38)
        Me.BuscarTratamiento.TabIndex = 4
        Me.BuscarTratamiento.Text = "Buscar"
        Me.BuscarTratamiento.UseVisualStyleBackColor = True
        '
        'MostrarTratamiento
        '
        Me.MostrarTratamiento.Location = New System.Drawing.Point(23, 88)
        Me.MostrarTratamiento.Name = "MostrarTratamiento"
        Me.MostrarTratamiento.Size = New System.Drawing.Size(106, 38)
        Me.MostrarTratamiento.TabIndex = 6
        Me.MostrarTratamiento.Text = "Mostrar"
        Me.MostrarTratamiento.UseVisualStyleBackColor = True
        '
        'AgregarTratamiento
        '
        Me.AgregarTratamiento.Location = New System.Drawing.Point(23, 43)
        Me.AgregarTratamiento.Name = "AgregarTratamiento"
        Me.AgregarTratamiento.Size = New System.Drawing.Size(106, 38)
        Me.AgregarTratamiento.TabIndex = 3
        Me.AgregarTratamiento.Text = "Agregar"
        Me.AgregarTratamiento.UseVisualStyleBackColor = True
        '
        'TratamientoTableAdapter
        '
        Me.TratamientoTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CategoriaTableAdapter = Nothing
        Me.TableAdapterManager.ClienteTableAdapter = Nothing
        Me.TableAdapterManager.DetalleFacturaTableAdapter = Nothing
        Me.TableAdapterManager.DetallePagoTableAdapter = Nothing
        Me.TableAdapterManager.FacturaTableAdapter = Nothing
        Me.TableAdapterManager.MascotaTableAdapter = Nothing
        Me.TableAdapterManager.MedicinaTableAdapter = Nothing
        Me.TableAdapterManager.PagoTableAdapter = Nothing
        Me.TableAdapterManager.ProductoTableAdapter = Nothing
        Me.TableAdapterManager.ProveedorTableAdapter = Nothing
        Me.TableAdapterManager.ServicioTableAdapter = Nothing
        Me.TableAdapterManager.TipoTableAdapter = Nothing
        Me.TableAdapterManager.TratamientoTableAdapter = Me.TratamientoTableAdapter
        Me.TableAdapterManager.UpdateOrder = Manchas.VeterinariaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.VacunaTableAdapter = Nothing
        '
        'Tratamiento
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.Aquamarine
        Me.ClientSize = New System.Drawing.Size(1197, 389)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Tratamiento"
        Me.Text = "Tratamiento"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.TratamientoBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VeterinariaDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        CType(Me.TratamientoDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents VeterinariaDataSet As VeterinariaDataSet
    Friend WithEvents TratamientoBindingSource As BindingSource
    Friend WithEvents TratamientoTableAdapter As VeterinariaDataSetTableAdapters.TratamientoTableAdapter
    Friend WithEvents TableAdapterManager As VeterinariaDataSetTableAdapters.TableAdapterManager
    Friend WithEvents CodTratamientoTextBox As TextBox
    Friend WithEvents TratamientoTextBox As TextBox
    Friend WithEvents DescripcionTextBox As TextBox
    Friend WithEvents CostoTextBox As TextBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents TratamientoDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents LimpiarTrtamiento As Button
    Friend WithEvents ModificarTratamiento As Button
    Friend WithEvents EliminarTratamiento As Button
    Friend WithEvents BuscarTratamiento As Button
    Friend WithEvents MostrarTratamiento As Button
    Friend WithEvents AgregarTratamiento As Button
End Class
