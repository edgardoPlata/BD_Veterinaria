﻿Public Class Medicina

    Sub Limpiar_Medicina()

        CodMedicinaTextBox.Clear()
        NombreMedicina.Clear()
        PrecioTextBox.Clear()
        FechaVencimeintoTextBox.Clear()

    End Sub

    Private Sub Medicina_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: esta línea de código carga datos en la tabla 'VeterinariaDataSet.Medicina' Puede moverla o quitarla según sea necesario.
        Me.MedicinaTableAdapter.Fill(Me.VeterinariaDataSet.Medicina)
        Limpiar_Medicina()


    End Sub


    Private Sub AgregarMedicina_Click(sender As Object, e As EventArgs) Handles AgregarMedicina.Click
        Me.MedicinaTableAdapter.AgregarMedicina(CodMedicinaTextBox.Text, NombreMedicina.Text, PrecioTextBox.Text, FechaVencimeintoTextBox.Text)
        Me.MedicinaTableAdapter.Fill(Me.VeterinariaDataSet.Medicina)
        Limpiar_Medicina()


    End Sub

    Private Sub BuscarMedicina_Click(sender As Object, e As EventArgs) Handles BuscarMedicina.Click
        Me.MedicinaTableAdapter.BuscarMedicina(Me.VeterinariaDataSet.Medicina, CodMedicinaTextBox.Text)
    End Sub

    Private Sub ModicarMEdicina_Click(sender As Object, e As EventArgs) Handles ModicarMEdicina.Click
        Me.MedicinaTableAdapter.ModificarMedicina(CodMedicinaTextBox.Text, NombreMedicina.Text, PrecioTextBox.Text, FechaVencimeintoTextBox.Text)
        Me.MedicinaTableAdapter.Fill(Me.VeterinariaDataSet.Medicina)
        Limpiar_Medicina()

    End Sub

    Private Sub EliminarMEdicina_Click(sender As Object, e As EventArgs) Handles EliminarMEdicina.Click
        Me.MedicinaTableAdapter.EliminarMedicina(CodMedicinaTextBox.Text)
        Me.MedicinaTableAdapter.Fill(Me.VeterinariaDataSet.Medicina)
        Limpiar_Medicina()

    End Sub

    Private Sub MostrarMedicina_Click(sender As Object, e As EventArgs) Handles MostrarMedicina.Click
        Me.MedicinaTableAdapter.Fill(Me.VeterinariaDataSet.Medicina)
        Limpiar_Medicina()
    End Sub

    Private Sub LimpiarMEdicina_Click(sender As Object, e As EventArgs) Handles LimpiarMEdicina.Click
        Limpiar_Medicina()
    End Sub
End Class