﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class Principal
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Principal))
        Me.Consulta = New System.Windows.Forms.Label()
        Me.Proveedores = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.VacunaMenu = New System.Windows.Forms.PictureBox()
        Me.TratamientoMenu = New System.Windows.Forms.PictureBox()
        Me.MedicinaMEnu = New System.Windows.Forms.PictureBox()
        Me.ConsultasMenu = New System.Windows.Forms.PictureBox()
        Me.ProveedoresMenu = New System.Windows.Forms.PictureBox()
        Me.ServiciosMenu = New System.Windows.Forms.PictureBox()
        Me.PrintPreviewControl1 = New System.Windows.Forms.PrintPreviewControl()
        CType(Me.VacunaMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TratamientoMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MedicinaMEnu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ConsultasMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ProveedoresMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ServiciosMenu, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Consulta
        '
        Me.Consulta.AutoSize = True
        Me.Consulta.BackColor = System.Drawing.Color.Cyan
        Me.Consulta.Font = New System.Drawing.Font("Times New Roman", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Consulta.Location = New System.Drawing.Point(79, 284)
        Me.Consulta.Name = "Consulta"
        Me.Consulta.Size = New System.Drawing.Size(145, 37)
        Me.Consulta.TabIndex = 1
        Me.Consulta.Text = "Servicios"
        '
        'Proveedores
        '
        Me.Proveedores.AutoSize = True
        Me.Proveedores.BackColor = System.Drawing.Color.Cyan
        Me.Proveedores.Font = New System.Drawing.Font("Times New Roman", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Proveedores.Location = New System.Drawing.Point(1361, 284)
        Me.Proveedores.Name = "Proveedores"
        Me.Proveedores.Size = New System.Drawing.Size(192, 37)
        Me.Proveedores.TabIndex = 3
        Me.Proveedores.Text = "Proveedores"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.BackColor = System.Drawing.Color.Cyan
        Me.Label2.Font = New System.Drawing.Font("Times New Roman", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(1715, 284)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(156, 37)
        Me.Label2.TabIndex = 5
        Me.Label2.Text = "Consultas"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.BackColor = System.Drawing.Color.Cyan
        Me.Label1.Font = New System.Drawing.Font("Times New Roman", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(383, 284)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(149, 37)
        Me.Label1.TabIndex = 7
        Me.Label1.Text = "Medicina"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.BackColor = System.Drawing.Color.Cyan
        Me.Label3.Font = New System.Drawing.Font("Times New Roman", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(720, 284)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(205, 37)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Tratamientos"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.BackColor = System.Drawing.Color.Cyan
        Me.Label4.Font = New System.Drawing.Font("Times New Roman", 19.8!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label4.Location = New System.Drawing.Point(1069, 284)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(133, 37)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Vacunas"
        '
        'VacunaMenu
        '
        Me.VacunaMenu.BackColor = System.Drawing.Color.White
        Me.VacunaMenu.Image = CType(resources.GetObject("VacunaMenu.Image"), System.Drawing.Image)
        Me.VacunaMenu.Location = New System.Drawing.Point(1061, 115)
        Me.VacunaMenu.Name = "VacunaMenu"
        Me.VacunaMenu.Size = New System.Drawing.Size(128, 128)
        Me.VacunaMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.VacunaMenu.TabIndex = 10
        Me.VacunaMenu.TabStop = False
        '
        'TratamientoMenu
        '
        Me.TratamientoMenu.BackColor = System.Drawing.Color.White
        Me.TratamientoMenu.Image = CType(resources.GetObject("TratamientoMenu.Image"), System.Drawing.Image)
        Me.TratamientoMenu.Location = New System.Drawing.Point(747, 115)
        Me.TratamientoMenu.Name = "TratamientoMenu"
        Me.TratamientoMenu.Size = New System.Drawing.Size(128, 128)
        Me.TratamientoMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.TratamientoMenu.TabIndex = 8
        Me.TratamientoMenu.TabStop = False
        '
        'MedicinaMEnu
        '
        Me.MedicinaMEnu.BackColor = System.Drawing.Color.White
        Me.MedicinaMEnu.Image = CType(resources.GetObject("MedicinaMEnu.Image"), System.Drawing.Image)
        Me.MedicinaMEnu.Location = New System.Drawing.Point(390, 115)
        Me.MedicinaMEnu.Name = "MedicinaMEnu"
        Me.MedicinaMEnu.Size = New System.Drawing.Size(128, 128)
        Me.MedicinaMEnu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.MedicinaMEnu.TabIndex = 6
        Me.MedicinaMEnu.TabStop = False
        '
        'ConsultasMenu
        '
        Me.ConsultasMenu.BackColor = System.Drawing.Color.White
        Me.ConsultasMenu.Image = CType(resources.GetObject("ConsultasMenu.Image"), System.Drawing.Image)
        Me.ConsultasMenu.Location = New System.Drawing.Point(1722, 115)
        Me.ConsultasMenu.Name = "ConsultasMenu"
        Me.ConsultasMenu.Size = New System.Drawing.Size(128, 128)
        Me.ConsultasMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.ConsultasMenu.TabIndex = 4
        Me.ConsultasMenu.TabStop = False
        '
        'ProveedoresMenu
        '
        Me.ProveedoresMenu.BackColor = System.Drawing.Color.White
        Me.ProveedoresMenu.Image = CType(resources.GetObject("ProveedoresMenu.Image"), System.Drawing.Image)
        Me.ProveedoresMenu.Location = New System.Drawing.Point(1385, 115)
        Me.ProveedoresMenu.Name = "ProveedoresMenu"
        Me.ProveedoresMenu.Size = New System.Drawing.Size(128, 128)
        Me.ProveedoresMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        Me.ProveedoresMenu.TabIndex = 2
        Me.ProveedoresMenu.TabStop = False
        '
        'ServiciosMenu
        '
        Me.ServiciosMenu.BackColor = System.Drawing.Color.White
        Me.ServiciosMenu.Image = CType(resources.GetObject("ServiciosMenu.Image"), System.Drawing.Image)
        Me.ServiciosMenu.Location = New System.Drawing.Point(86, 115)
        Me.ServiciosMenu.Name = "ServiciosMenu"
        Me.ServiciosMenu.Size = New System.Drawing.Size(128, 128)
        Me.ServiciosMenu.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ServiciosMenu.TabIndex = 0
        Me.ServiciosMenu.TabStop = False
        '
        'PrintPreviewControl1
        '
        Me.PrintPreviewControl1.Location = New System.Drawing.Point(340, 665)
        Me.PrintPreviewControl1.Name = "PrintPreviewControl1"
        Me.PrintPreviewControl1.Size = New System.Drawing.Size(8, 8)
        Me.PrintPreviewControl1.TabIndex = 13
        '
        'Principal
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoSize = True
        Me.BackColor = System.Drawing.Color.Turquoise
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(1924, 681)
        Me.Controls.Add(Me.PrintPreviewControl1)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.VacunaMenu)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TratamientoMenu)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.MedicinaMEnu)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.ConsultasMenu)
        Me.Controls.Add(Me.Proveedores)
        Me.Controls.Add(Me.ProveedoresMenu)
        Me.Controls.Add(Me.Consulta)
        Me.Controls.Add(Me.ServiciosMenu)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.IsMdiContainer = True
        Me.Name = "Principal"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Principal"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        CType(Me.VacunaMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TratamientoMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MedicinaMEnu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ConsultasMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ProveedoresMenu, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ServiciosMenu, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents ServiciosMenu As PictureBox
    Friend WithEvents Consulta As Label
    Friend WithEvents Proveedores As Label
    Friend WithEvents ProveedoresMenu As PictureBox
    Friend WithEvents Label2 As Label
    Friend WithEvents ConsultasMenu As PictureBox
    Friend WithEvents Label1 As Label
    Friend WithEvents MedicinaMEnu As PictureBox
    Friend WithEvents Label3 As Label
    Friend WithEvents TratamientoMenu As PictureBox
    Friend WithEvents Label4 As Label
    Friend WithEvents VacunaMenu As PictureBox
    Friend WithEvents PrintPreviewControl1 As PrintPreviewControl
End Class
