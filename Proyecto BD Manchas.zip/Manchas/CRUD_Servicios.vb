﻿Imports System.Data.SqlClient

Public Class CRUD_Servicios

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles Label2.Click

    End Sub

    Private Sub GroupBox1_Enter(sender As Object, e As EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub CRUD_Servicios_Load(sender As Object, e As EventArgs) Handles MyBase.Load


        Mostrar_Datos_Cliente()
        Mostrar_Datos_Mascotas()



    End Sub

    Private Sub DataGridView2_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles Datos_Mascotas_.CellContentClick

    End Sub

    Sub limpiar()

        TXT_Codigo.Clear()
        Nombre_Cliente.Clear()
        Apellido_Cliente.Clear()
        Cedula_Cliente.Clear()
        Direccion.Clear()
        Telefono_Cliente.Clear()
        Codigo_Mascota.Clear()
        Nombre_Mascota.Clear()
        Tipo_Mascota.Clear()
        Raza_Mascota.Clear()
        Peso_Mascota.Clear()
        Codigo_Cliente_Mascota.Clear()
        Categoria_Mascota.Clear()


    End Sub

    Sub Agregar_Cliente()
        Dim cmd As New SqlCommand

        Try
            Abrir_Conexion()

            cmd = New SqlCommand("Agregar_Cliente", conexion)
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Parameters.AddWithValue("@CodCliente", TXT_Codigo.Text.ToString)
            cmd.Parameters.AddWithValue("@Nombre", Nombre_Cliente.Text.ToString)
            cmd.Parameters.AddWithValue("@Apellido", Apellido_Cliente.Text.ToString)
            cmd.Parameters.AddWithValue("@Cedula", Cedula_Cliente.Text.ToString)
            cmd.Parameters.AddWithValue("@Direccion", Direccion.Text.ToString)
            cmd.Parameters.AddWithValue("@Telefono", Telefono_Cliente.Text)
            cmd.ExecuteNonQuery()
            cerrar_conexion()
            limpiar()
        Catch ex As Exception

        End Try


    End Sub

    Sub Agregar_Mascota()
        Dim cmd As New SqlCommand
        Try
            Abrir_Conexion()

            cmd = New SqlCommand("Agregar_Mascota", conexion)
            cmd.CommandType = CommandType.StoredProcedure

            cmd.Parameters.AddWithValue("@CodMascota", Codigo_Mascota.Text.ToString)
            cmd.Parameters.AddWithValue("@Nombre", Nombre_Mascota.Text.ToString)
            cmd.Parameters.AddWithValue("@IdTipo", Tipo_Mascota.Text.ToString)
            cmd.Parameters.AddWithValue("@Raza", Raza_Mascota.Text.ToString)
            cmd.Parameters.AddWithValue("@Peso", Peso_Mascota.Text.ToString)
            cmd.Parameters.AddWithValue("@IdCliente", Codigo_Cliente_Mascota.Text.ToString)
            cmd.Parameters.AddWithValue("@IdCategoria", Categoria_Mascota.Text.ToString)

            cmd.ExecuteNonQuery()
            cerrar_conexion()
            limpiar()
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Agregar_Cliente()
        Agregar_Mascota()


    End Sub


    Sub Mostrar_Datos_Cliente()

        Dim dt As New DataTable
        Dim da As SqlDataAdapter

        Try
            Abrir_Conexion()

            da = New SqlDataAdapter("Mostrar_Cliente", conexion)
            da.Fill(dt)
            Datos_Cliente_.DataSource = dt
            cerrar_conexion()


        Catch ex As Exception

        End Try

    End Sub

    Sub Mostrar_Datos_Mascotas()
        Dim dt As New DataTable
        Dim da As SqlDataAdapter

        Try
            Abrir_Conexion()

            da = New SqlDataAdapter("Mostrar_Mascota", conexion)
            da.Fill(dt)
            Datos_Mascotas_.DataSource = dt
            cerrar_conexion()


        Catch ex As Exception

        End Try

    End Sub


    Sub Buscar_Cliente()

        Dim dt As New DataTable
        Dim da As SqlDataAdapter

        Try
            Abrir_Conexion()

            da = New SqlDataAdapter("Buscar_Cliente", conexion)
            da.SelectCommand.CommandType = CommandType.StoredProcedure
            da.SelectCommand.Parameters.AddWithValue("@Busqueda", Busqueda_Cliente.Text)

            da.Fill(dt)

            Datos_Cliente_.DataSource = dt
            cerrar_conexion()

        Catch ex As Exception

        End Try


    End Sub

    Sub Buscar_Mascota()
        Dim dt As New DataTable
        Dim da As SqlDataAdapter

        Try
            Abrir_Conexion()

            da = New SqlDataAdapter("Buscar_Cliente", conexion)
            da.SelectCommand.CommandType = CommandType.StoredProcedure
            da.SelectCommand.Parameters.AddWithValue("@BusquedaMascota", Busqueda_Mascota.Text)

            da.Fill(dt)

            Datos_Mascotas_.DataSource = dt
            cerrar_conexion()

        Catch ex As Exception

        End Try
    End Sub
    Private Sub Busqueda_Cliente_TextChanged(sender As Object, e As EventArgs) Handles Busqueda_Cliente.TextChanged
        Buscar_Cliente()
    End Sub

    Private Sub Busqueda_Mascota_TextChanged(sender As Object, e As EventArgs) Handles Busqueda_Mascota.TextChanged
        Buscar_Mascota()

    End Sub

    Private Sub Datos_Cliente__CellContentDoubleClick(sender As Object, e As DataGridViewCellEventArgs) Handles Datos_Cliente_.CellContentDoubleClick

        Try
            TXT_Codigo.Text = Datos_Cliente_.SelectedCells.Item(0).Value
            Nombre_Cliente = Datos_Cliente_.SelectedCells.Item(2).Value


        Catch ex As Exception

        End Try


    End Sub
End Class