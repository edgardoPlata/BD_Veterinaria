﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Servicios
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim CodClienteLabel As System.Windows.Forms.Label
        Dim NombreLabel As System.Windows.Forms.Label
        Dim ApellidoLabel As System.Windows.Forms.Label
        Dim CedulaLabel As System.Windows.Forms.Label
        Dim DireccionLabel As System.Windows.Forms.Label
        Dim TelefonoLabel As System.Windows.Forms.Label
        Dim CodMascotaLabel As System.Windows.Forms.Label
        Dim NombreLabel1 As System.Windows.Forms.Label
        Dim IdTipoLabel As System.Windows.Forms.Label
        Dim RazaLabel As System.Windows.Forms.Label
        Dim PesoLabel As System.Windows.Forms.Label
        Dim IdClienteLabel As System.Windows.Forms.Label
        Dim TipoServicioLabel As System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.CodClienteTextBox = New System.Windows.Forms.TextBox()
        Me.NombreCliente = New System.Windows.Forms.TextBox()
        Me.ApellidoTextBox = New System.Windows.Forms.TextBox()
        Me.CedulaTextBox = New System.Windows.Forms.TextBox()
        Me.DireccionTextBox = New System.Windows.Forms.TextBox()
        Me.TelefonoTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.CodMascotaTextBox = New System.Windows.Forms.TextBox()
        Me.NombreMascota = New System.Windows.Forms.TextBox()
        Me.IdTipoTextBox = New System.Windows.Forms.TextBox()
        Me.RazaTextBox = New System.Windows.Forms.TextBox()
        Me.PesoTextBox = New System.Windows.Forms.TextBox()
        Me.IdClienteTextBox = New System.Windows.Forms.TextBox()
        Me.TipoServicioTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.BuscarMAscota = New System.Windows.Forms.Button()
        Me.BuscarCliente = New System.Windows.Forms.Button()
        Me.EliminarMascota = New System.Windows.Forms.Button()
        Me.EliminarCliente = New System.Windows.Forms.Button()
        Me.MostrarMAscota = New System.Windows.Forms.Button()
        Me.Mostrar = New System.Windows.Forms.Button()
        Me.ModificarMascota = New System.Windows.Forms.Button()
        Me.ModificarCliente = New System.Windows.Forms.Button()
        Me.AgregarMascota = New System.Windows.Forms.Button()
        Me.AgregarCliente = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.ClienteDataGridView = New System.Windows.Forms.DataGridView()
        Me.GroupBox5 = New System.Windows.Forms.GroupBox()
        Me.MascotaDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.MascotaBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.VeterinariaDataSet = New Manchas.VeterinariaDataSet()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ClienteBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ClienteTableAdapter = New Manchas.VeterinariaDataSetTableAdapters.ClienteTableAdapter()
        Me.TableAdapterManager = New Manchas.VeterinariaDataSetTableAdapters.TableAdapterManager()
        Me.MascotaTableAdapter = New Manchas.VeterinariaDataSetTableAdapters.MascotaTableAdapter()
        CodClienteLabel = New System.Windows.Forms.Label()
        NombreLabel = New System.Windows.Forms.Label()
        ApellidoLabel = New System.Windows.Forms.Label()
        CedulaLabel = New System.Windows.Forms.Label()
        DireccionLabel = New System.Windows.Forms.Label()
        TelefonoLabel = New System.Windows.Forms.Label()
        CodMascotaLabel = New System.Windows.Forms.Label()
        NombreLabel1 = New System.Windows.Forms.Label()
        IdTipoLabel = New System.Windows.Forms.Label()
        RazaLabel = New System.Windows.Forms.Label()
        PesoLabel = New System.Windows.Forms.Label()
        IdClienteLabel = New System.Windows.Forms.Label()
        TipoServicioLabel = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        CType(Me.ClienteDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox5.SuspendLayout()
        CType(Me.MascotaDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.MascotaBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VeterinariaDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ClienteBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'CodClienteLabel
        '
        CodClienteLabel.AutoSize = True
        CodClienteLabel.Location = New System.Drawing.Point(6, 43)
        CodClienteLabel.Name = "CodClienteLabel"
        CodClienteLabel.Size = New System.Drawing.Size(146, 28)
        CodClienteLabel.TabIndex = 0
        CodClienteLabel.Text = "Cod Cliente:"
        '
        'NombreLabel
        '
        NombreLabel.AutoSize = True
        NombreLabel.Location = New System.Drawing.Point(6, 85)
        NombreLabel.Name = "NombreLabel"
        NombreLabel.Size = New System.Drawing.Size(104, 28)
        NombreLabel.TabIndex = 2
        NombreLabel.Text = "Nombre:"
        '
        'ApellidoLabel
        '
        ApellidoLabel.AutoSize = True
        ApellidoLabel.Location = New System.Drawing.Point(6, 127)
        ApellidoLabel.Name = "ApellidoLabel"
        ApellidoLabel.Size = New System.Drawing.Size(108, 28)
        ApellidoLabel.TabIndex = 4
        ApellidoLabel.Text = "Apellido:"
        '
        'CedulaLabel
        '
        CedulaLabel.AutoSize = True
        CedulaLabel.Location = New System.Drawing.Point(6, 169)
        CedulaLabel.Name = "CedulaLabel"
        CedulaLabel.Size = New System.Drawing.Size(94, 28)
        CedulaLabel.TabIndex = 6
        CedulaLabel.Text = "Cedula:"
        '
        'DireccionLabel
        '
        DireccionLabel.AutoSize = True
        DireccionLabel.Location = New System.Drawing.Point(6, 211)
        DireccionLabel.Name = "DireccionLabel"
        DireccionLabel.Size = New System.Drawing.Size(123, 28)
        DireccionLabel.TabIndex = 8
        DireccionLabel.Text = "Direccion:"
        '
        'TelefonoLabel
        '
        TelefonoLabel.AutoSize = True
        TelefonoLabel.Location = New System.Drawing.Point(6, 253)
        TelefonoLabel.Name = "TelefonoLabel"
        TelefonoLabel.Size = New System.Drawing.Size(112, 28)
        TelefonoLabel.TabIndex = 10
        TelefonoLabel.Text = "Telefono:"
        '
        'CodMascotaLabel
        '
        CodMascotaLabel.AutoSize = True
        CodMascotaLabel.Location = New System.Drawing.Point(15, 32)
        CodMascotaLabel.Name = "CodMascotaLabel"
        CodMascotaLabel.Size = New System.Drawing.Size(160, 28)
        CodMascotaLabel.TabIndex = 0
        CodMascotaLabel.Text = "Cod Mascota:"
        '
        'NombreLabel1
        '
        NombreLabel1.AutoSize = True
        NombreLabel1.Location = New System.Drawing.Point(15, 74)
        NombreLabel1.Name = "NombreLabel1"
        NombreLabel1.Size = New System.Drawing.Size(104, 28)
        NombreLabel1.TabIndex = 2
        NombreLabel1.Text = "Nombre:"
        '
        'IdTipoLabel
        '
        IdTipoLabel.AutoSize = True
        IdTipoLabel.Location = New System.Drawing.Point(15, 116)
        IdTipoLabel.Name = "IdTipoLabel"
        IdTipoLabel.Size = New System.Drawing.Size(94, 28)
        IdTipoLabel.TabIndex = 4
        IdTipoLabel.Text = "Id Tipo:"
        '
        'RazaLabel
        '
        RazaLabel.AutoSize = True
        RazaLabel.Location = New System.Drawing.Point(15, 158)
        RazaLabel.Name = "RazaLabel"
        RazaLabel.Size = New System.Drawing.Size(72, 28)
        RazaLabel.TabIndex = 6
        RazaLabel.Text = "Raza:"
        '
        'PesoLabel
        '
        PesoLabel.AutoSize = True
        PesoLabel.Location = New System.Drawing.Point(15, 200)
        PesoLabel.Name = "PesoLabel"
        PesoLabel.Size = New System.Drawing.Size(70, 28)
        PesoLabel.TabIndex = 8
        PesoLabel.Text = "Peso:"
        '
        'IdClienteLabel
        '
        IdClienteLabel.AutoSize = True
        IdClienteLabel.Location = New System.Drawing.Point(15, 242)
        IdClienteLabel.Name = "IdClienteLabel"
        IdClienteLabel.Size = New System.Drawing.Size(125, 28)
        IdClienteLabel.TabIndex = 10
        IdClienteLabel.Text = "Id Cliente:"
        '
        'TipoServicioLabel
        '
        TipoServicioLabel.AutoSize = True
        TipoServicioLabel.Location = New System.Drawing.Point(15, 284)
        TipoServicioLabel.Name = "TipoServicioLabel"
        TipoServicioLabel.Size = New System.Drawing.Size(162, 28)
        TipoServicioLabel.TabIndex = 12
        TipoServicioLabel.Text = "Tipo Servicio:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(CodClienteLabel)
        Me.GroupBox1.Controls.Add(Me.CodClienteTextBox)
        Me.GroupBox1.Controls.Add(NombreLabel)
        Me.GroupBox1.Controls.Add(Me.NombreCliente)
        Me.GroupBox1.Controls.Add(ApellidoLabel)
        Me.GroupBox1.Controls.Add(Me.ApellidoTextBox)
        Me.GroupBox1.Controls.Add(CedulaLabel)
        Me.GroupBox1.Controls.Add(Me.CedulaTextBox)
        Me.GroupBox1.Controls.Add(DireccionLabel)
        Me.GroupBox1.Controls.Add(Me.DireccionTextBox)
        Me.GroupBox1.Controls.Add(TelefonoLabel)
        Me.GroupBox1.Controls.Add(Me.TelefonoTextBox)
        Me.GroupBox1.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.GroupBox1.Font = New System.Drawing.Font("Arial Black", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(51, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(411, 322)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Cliente"
        '
        'CodClienteTextBox
        '
        Me.CodClienteTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClienteBindingSource, "CodCliente", True))
        Me.CodClienteTextBox.Location = New System.Drawing.Point(164, 40)
        Me.CodClienteTextBox.Name = "CodClienteTextBox"
        Me.CodClienteTextBox.Size = New System.Drawing.Size(221, 36)
        Me.CodClienteTextBox.TabIndex = 1
        '
        'NombreCliente
        '
        Me.NombreCliente.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClienteBindingSource, "Nombre", True))
        Me.NombreCliente.Location = New System.Drawing.Point(164, 82)
        Me.NombreCliente.Name = "NombreCliente"
        Me.NombreCliente.Size = New System.Drawing.Size(221, 36)
        Me.NombreCliente.TabIndex = 3
        '
        'ApellidoTextBox
        '
        Me.ApellidoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClienteBindingSource, "Apellido", True))
        Me.ApellidoTextBox.Location = New System.Drawing.Point(164, 124)
        Me.ApellidoTextBox.Name = "ApellidoTextBox"
        Me.ApellidoTextBox.Size = New System.Drawing.Size(221, 36)
        Me.ApellidoTextBox.TabIndex = 5
        '
        'CedulaTextBox
        '
        Me.CedulaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClienteBindingSource, "Cedula", True))
        Me.CedulaTextBox.Location = New System.Drawing.Point(164, 166)
        Me.CedulaTextBox.Name = "CedulaTextBox"
        Me.CedulaTextBox.Size = New System.Drawing.Size(221, 36)
        Me.CedulaTextBox.TabIndex = 7
        '
        'DireccionTextBox
        '
        Me.DireccionTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClienteBindingSource, "Direccion", True))
        Me.DireccionTextBox.Location = New System.Drawing.Point(164, 208)
        Me.DireccionTextBox.Name = "DireccionTextBox"
        Me.DireccionTextBox.Size = New System.Drawing.Size(221, 36)
        Me.DireccionTextBox.TabIndex = 9
        '
        'TelefonoTextBox
        '
        Me.TelefonoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ClienteBindingSource, "Telefono", True))
        Me.TelefonoTextBox.Location = New System.Drawing.Point(164, 250)
        Me.TelefonoTextBox.Name = "TelefonoTextBox"
        Me.TelefonoTextBox.Size = New System.Drawing.Size(221, 36)
        Me.TelefonoTextBox.TabIndex = 11
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(CodMascotaLabel)
        Me.GroupBox2.Controls.Add(Me.CodMascotaTextBox)
        Me.GroupBox2.Controls.Add(NombreLabel1)
        Me.GroupBox2.Controls.Add(Me.NombreMascota)
        Me.GroupBox2.Controls.Add(IdTipoLabel)
        Me.GroupBox2.Controls.Add(Me.IdTipoTextBox)
        Me.GroupBox2.Controls.Add(RazaLabel)
        Me.GroupBox2.Controls.Add(Me.RazaTextBox)
        Me.GroupBox2.Controls.Add(PesoLabel)
        Me.GroupBox2.Controls.Add(Me.PesoTextBox)
        Me.GroupBox2.Controls.Add(IdClienteLabel)
        Me.GroupBox2.Controls.Add(Me.IdClienteTextBox)
        Me.GroupBox2.Controls.Add(TipoServicioLabel)
        Me.GroupBox2.Controls.Add(Me.TipoServicioTextBox)
        Me.GroupBox2.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.GroupBox2.Font = New System.Drawing.Font("Arial Black", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.Location = New System.Drawing.Point(579, 12)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(394, 322)
        Me.GroupBox2.TabIndex = 1
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Mascota"
        '
        'CodMascotaTextBox
        '
        Me.CodMascotaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MascotaBindingSource, "CodMascota", True))
        Me.CodMascotaTextBox.Location = New System.Drawing.Point(204, 29)
        Me.CodMascotaTextBox.Name = "CodMascotaTextBox"
        Me.CodMascotaTextBox.Size = New System.Drawing.Size(175, 36)
        Me.CodMascotaTextBox.TabIndex = 1
        '
        'NombreMascota
        '
        Me.NombreMascota.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MascotaBindingSource, "Nombre", True))
        Me.NombreMascota.Location = New System.Drawing.Point(204, 71)
        Me.NombreMascota.Name = "NombreMascota"
        Me.NombreMascota.Size = New System.Drawing.Size(175, 36)
        Me.NombreMascota.TabIndex = 3
        '
        'IdTipoTextBox
        '
        Me.IdTipoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MascotaBindingSource, "IdTipo", True))
        Me.IdTipoTextBox.Location = New System.Drawing.Point(204, 113)
        Me.IdTipoTextBox.Name = "IdTipoTextBox"
        Me.IdTipoTextBox.Size = New System.Drawing.Size(175, 36)
        Me.IdTipoTextBox.TabIndex = 5
        '
        'RazaTextBox
        '
        Me.RazaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MascotaBindingSource, "Raza", True))
        Me.RazaTextBox.Location = New System.Drawing.Point(204, 155)
        Me.RazaTextBox.Name = "RazaTextBox"
        Me.RazaTextBox.Size = New System.Drawing.Size(175, 36)
        Me.RazaTextBox.TabIndex = 7
        '
        'PesoTextBox
        '
        Me.PesoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MascotaBindingSource, "Peso", True))
        Me.PesoTextBox.Location = New System.Drawing.Point(204, 197)
        Me.PesoTextBox.Name = "PesoTextBox"
        Me.PesoTextBox.Size = New System.Drawing.Size(175, 36)
        Me.PesoTextBox.TabIndex = 9
        '
        'IdClienteTextBox
        '
        Me.IdClienteTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MascotaBindingSource, "IdCliente", True))
        Me.IdClienteTextBox.Location = New System.Drawing.Point(204, 239)
        Me.IdClienteTextBox.Name = "IdClienteTextBox"
        Me.IdClienteTextBox.Size = New System.Drawing.Size(175, 36)
        Me.IdClienteTextBox.TabIndex = 11
        '
        'TipoServicioTextBox
        '
        Me.TipoServicioTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.MascotaBindingSource, "TipoServicio", True))
        Me.TipoServicioTextBox.Location = New System.Drawing.Point(204, 281)
        Me.TipoServicioTextBox.Name = "TipoServicioTextBox"
        Me.TipoServicioTextBox.Size = New System.Drawing.Size(175, 36)
        Me.TipoServicioTextBox.TabIndex = 13
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.Button2)
        Me.GroupBox3.Controls.Add(Me.Button1)
        Me.GroupBox3.Controls.Add(Me.BuscarMAscota)
        Me.GroupBox3.Controls.Add(Me.BuscarCliente)
        Me.GroupBox3.Controls.Add(Me.EliminarMascota)
        Me.GroupBox3.Controls.Add(Me.EliminarCliente)
        Me.GroupBox3.Controls.Add(Me.MostrarMAscota)
        Me.GroupBox3.Controls.Add(Me.Mostrar)
        Me.GroupBox3.Controls.Add(Me.ModificarMascota)
        Me.GroupBox3.Controls.Add(Me.ModificarCliente)
        Me.GroupBox3.Controls.Add(Me.AgregarMascota)
        Me.GroupBox3.Controls.Add(Me.AgregarCliente)
        Me.GroupBox3.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox3.Location = New System.Drawing.Point(62, 340)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(911, 119)
        Me.GroupBox3.TabIndex = 2
        Me.GroupBox3.TabStop = False
        Me.GroupBox3.Text = "Opciones"
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(775, 70)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(123, 35)
        Me.Button2.TabIndex = 11
        Me.Button2.Text = "Limpiar"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(264, 70)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(123, 35)
        Me.Button1.TabIndex = 5
        Me.Button1.Text = "Limpiar"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'BuscarMAscota
        '
        Me.BuscarMAscota.Location = New System.Drawing.Point(775, 29)
        Me.BuscarMAscota.Name = "BuscarMAscota"
        Me.BuscarMAscota.Size = New System.Drawing.Size(123, 35)
        Me.BuscarMAscota.TabIndex = 8
        Me.BuscarMAscota.Text = "Buscar"
        Me.BuscarMAscota.UseVisualStyleBackColor = True
        '
        'BuscarCliente
        '
        Me.BuscarCliente.Location = New System.Drawing.Point(264, 29)
        Me.BuscarCliente.Name = "BuscarCliente"
        Me.BuscarCliente.Size = New System.Drawing.Size(123, 35)
        Me.BuscarCliente.TabIndex = 2
        Me.BuscarCliente.Text = "Buscar"
        Me.BuscarCliente.UseVisualStyleBackColor = True
        '
        'EliminarMascota
        '
        Me.EliminarMascota.Location = New System.Drawing.Point(646, 70)
        Me.EliminarMascota.Name = "EliminarMascota"
        Me.EliminarMascota.Size = New System.Drawing.Size(123, 35)
        Me.EliminarMascota.TabIndex = 10
        Me.EliminarMascota.Text = "Eliminar"
        Me.EliminarMascota.UseVisualStyleBackColor = True
        '
        'EliminarCliente
        '
        Me.EliminarCliente.Location = New System.Drawing.Point(135, 70)
        Me.EliminarCliente.Name = "EliminarCliente"
        Me.EliminarCliente.Size = New System.Drawing.Size(123, 35)
        Me.EliminarCliente.TabIndex = 4
        Me.EliminarCliente.Text = "Eliminar"
        Me.EliminarCliente.UseVisualStyleBackColor = True
        '
        'MostrarMAscota
        '
        Me.MostrarMAscota.Location = New System.Drawing.Point(646, 29)
        Me.MostrarMAscota.Name = "MostrarMAscota"
        Me.MostrarMAscota.Size = New System.Drawing.Size(123, 35)
        Me.MostrarMAscota.TabIndex = 7
        Me.MostrarMAscota.Text = "Mostrar"
        Me.MostrarMAscota.UseVisualStyleBackColor = True
        '
        'Mostrar
        '
        Me.Mostrar.Location = New System.Drawing.Point(135, 29)
        Me.Mostrar.Name = "Mostrar"
        Me.Mostrar.Size = New System.Drawing.Size(123, 35)
        Me.Mostrar.TabIndex = 1
        Me.Mostrar.Text = "Mostrar"
        Me.Mostrar.UseVisualStyleBackColor = True
        '
        'ModificarMascota
        '
        Me.ModificarMascota.Location = New System.Drawing.Point(517, 70)
        Me.ModificarMascota.Name = "ModificarMascota"
        Me.ModificarMascota.Size = New System.Drawing.Size(123, 35)
        Me.ModificarMascota.TabIndex = 9
        Me.ModificarMascota.Text = "Modificar"
        Me.ModificarMascota.UseVisualStyleBackColor = True
        '
        'ModificarCliente
        '
        Me.ModificarCliente.Location = New System.Drawing.Point(6, 70)
        Me.ModificarCliente.Name = "ModificarCliente"
        Me.ModificarCliente.Size = New System.Drawing.Size(123, 35)
        Me.ModificarCliente.TabIndex = 3
        Me.ModificarCliente.Text = "Modificar"
        Me.ModificarCliente.UseVisualStyleBackColor = True
        '
        'AgregarMascota
        '
        Me.AgregarMascota.Location = New System.Drawing.Point(517, 29)
        Me.AgregarMascota.Name = "AgregarMascota"
        Me.AgregarMascota.Size = New System.Drawing.Size(123, 35)
        Me.AgregarMascota.TabIndex = 6
        Me.AgregarMascota.Text = "Agregar"
        Me.AgregarMascota.UseVisualStyleBackColor = True
        '
        'AgregarCliente
        '
        Me.AgregarCliente.Location = New System.Drawing.Point(6, 29)
        Me.AgregarCliente.Name = "AgregarCliente"
        Me.AgregarCliente.Size = New System.Drawing.Size(123, 35)
        Me.AgregarCliente.TabIndex = 0
        Me.AgregarCliente.Text = "Agregar"
        Me.AgregarCliente.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.ClienteDataGridView)
        Me.GroupBox4.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox4.Location = New System.Drawing.Point(68, 465)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(905, 237)
        Me.GroupBox4.TabIndex = 3
        Me.GroupBox4.TabStop = False
        Me.GroupBox4.Text = "Datos Cliente"
        '
        'ClienteDataGridView
        '
        Me.ClienteDataGridView.AutoGenerateColumns = False
        Me.ClienteDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.ClienteDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6})
        Me.ClienteDataGridView.DataSource = Me.ClienteBindingSource
        Me.ClienteDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ClienteDataGridView.Location = New System.Drawing.Point(3, 26)
        Me.ClienteDataGridView.Name = "ClienteDataGridView"
        Me.ClienteDataGridView.RowHeadersWidth = 51
        Me.ClienteDataGridView.RowTemplate.Height = 24
        Me.ClienteDataGridView.Size = New System.Drawing.Size(899, 208)
        Me.ClienteDataGridView.TabIndex = 0
        '
        'GroupBox5
        '
        Me.GroupBox5.Controls.Add(Me.MascotaDataGridView)
        Me.GroupBox5.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox5.Location = New System.Drawing.Point(71, 724)
        Me.GroupBox5.Name = "GroupBox5"
        Me.GroupBox5.Size = New System.Drawing.Size(902, 243)
        Me.GroupBox5.TabIndex = 4
        Me.GroupBox5.TabStop = False
        Me.GroupBox5.Text = "Datos Mascota"
        '
        'MascotaDataGridView
        '
        Me.MascotaDataGridView.AutoGenerateColumns = False
        Me.MascotaDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.MascotaDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13})
        Me.MascotaDataGridView.DataSource = Me.MascotaBindingSource
        Me.MascotaDataGridView.Dock = System.Windows.Forms.DockStyle.Fill
        Me.MascotaDataGridView.Location = New System.Drawing.Point(3, 26)
        Me.MascotaDataGridView.Name = "MascotaDataGridView"
        Me.MascotaDataGridView.RowHeadersWidth = 51
        Me.MascotaDataGridView.RowTemplate.Height = 24
        Me.MascotaDataGridView.Size = New System.Drawing.Size(896, 214)
        Me.MascotaDataGridView.TabIndex = 0
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "CodMascota"
        Me.DataGridViewTextBoxColumn7.HeaderText = "CodMascota"
        Me.DataGridViewTextBoxColumn7.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        Me.DataGridViewTextBoxColumn7.Width = 125
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "Nombre"
        Me.DataGridViewTextBoxColumn8.HeaderText = "Nombre"
        Me.DataGridViewTextBoxColumn8.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        Me.DataGridViewTextBoxColumn8.Width = 125
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "IdTipo"
        Me.DataGridViewTextBoxColumn9.HeaderText = "IdTipo"
        Me.DataGridViewTextBoxColumn9.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        Me.DataGridViewTextBoxColumn9.Width = 125
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "Raza"
        Me.DataGridViewTextBoxColumn10.HeaderText = "Raza"
        Me.DataGridViewTextBoxColumn10.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        Me.DataGridViewTextBoxColumn10.Width = 125
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.DataPropertyName = "Peso"
        Me.DataGridViewTextBoxColumn11.HeaderText = "Peso"
        Me.DataGridViewTextBoxColumn11.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        Me.DataGridViewTextBoxColumn11.Width = 125
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.DataPropertyName = "IdCliente"
        Me.DataGridViewTextBoxColumn12.HeaderText = "IdCliente"
        Me.DataGridViewTextBoxColumn12.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        Me.DataGridViewTextBoxColumn12.Width = 125
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.DataPropertyName = "TipoServicio"
        Me.DataGridViewTextBoxColumn13.HeaderText = "TipoServicio"
        Me.DataGridViewTextBoxColumn13.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        Me.DataGridViewTextBoxColumn13.Width = 125
        '
        'MascotaBindingSource
        '
        Me.MascotaBindingSource.DataMember = "Mascota"
        Me.MascotaBindingSource.DataSource = Me.VeterinariaDataSet
        '
        'VeterinariaDataSet
        '
        Me.VeterinariaDataSet.DataSetName = "VeterinariaDataSet"
        Me.VeterinariaDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "CodCliente"
        Me.DataGridViewTextBoxColumn1.HeaderText = "CodCliente"
        Me.DataGridViewTextBoxColumn1.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        Me.DataGridViewTextBoxColumn1.Width = 125
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Nombre"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Nombre"
        Me.DataGridViewTextBoxColumn2.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        Me.DataGridViewTextBoxColumn2.Width = 125
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Apellido"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Apellido"
        Me.DataGridViewTextBoxColumn3.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        Me.DataGridViewTextBoxColumn3.Width = 125
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "Cedula"
        Me.DataGridViewTextBoxColumn4.HeaderText = "Cedula"
        Me.DataGridViewTextBoxColumn4.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        Me.DataGridViewTextBoxColumn4.Width = 125
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "Direccion"
        Me.DataGridViewTextBoxColumn5.HeaderText = "Direccion"
        Me.DataGridViewTextBoxColumn5.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        Me.DataGridViewTextBoxColumn5.Width = 125
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "Telefono"
        Me.DataGridViewTextBoxColumn6.HeaderText = "Telefono"
        Me.DataGridViewTextBoxColumn6.MinimumWidth = 6
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        Me.DataGridViewTextBoxColumn6.Width = 125
        '
        'ClienteBindingSource
        '
        Me.ClienteBindingSource.DataMember = "Cliente"
        Me.ClienteBindingSource.DataSource = Me.VeterinariaDataSet
        '
        'ClienteTableAdapter
        '
        Me.ClienteTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.CategoriaTableAdapter = Nothing
        Me.TableAdapterManager.ClienteTableAdapter = Me.ClienteTableAdapter
        Me.TableAdapterManager.DetalleFacturaTableAdapter = Nothing
        Me.TableAdapterManager.DetallePagoTableAdapter = Nothing
        Me.TableAdapterManager.FacturaTableAdapter = Nothing
        Me.TableAdapterManager.MascotaTableAdapter = Me.MascotaTableAdapter
        Me.TableAdapterManager.MedicinaTableAdapter = Nothing
        Me.TableAdapterManager.PagoTableAdapter = Nothing
        Me.TableAdapterManager.ProductoTableAdapter = Nothing
        Me.TableAdapterManager.ProveedorTableAdapter = Nothing
        Me.TableAdapterManager.ServicioTableAdapter = Nothing
        Me.TableAdapterManager.TipoTableAdapter = Nothing
        Me.TableAdapterManager.TratamientoTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = Manchas.VeterinariaDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.VacunaTableAdapter = Nothing
        '
        'MascotaTableAdapter
        '
        Me.MascotaTableAdapter.ClearBeforeFill = True
        '
        'Servicios
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.AutoSizeMode = System.Windows.Forms.AutoSizeMode.GrowAndShrink
        Me.BackColor = System.Drawing.Color.Cyan
        Me.ClientSize = New System.Drawing.Size(1037, 808)
        Me.Controls.Add(Me.GroupBox5)
        Me.Controls.Add(Me.GroupBox4)
        Me.Controls.Add(Me.GroupBox3)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.GroupBox1)
        Me.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.Name = "Servicios"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Servicios"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        CType(Me.ClienteDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox5.ResumeLayout(False)
        CType(Me.MascotaDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.MascotaBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VeterinariaDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ClienteBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents GroupBox1 As GroupBox
    Friend WithEvents GroupBox2 As GroupBox
    Friend WithEvents VeterinariaDataSet As VeterinariaDataSet
    Friend WithEvents ClienteBindingSource As BindingSource
    Friend WithEvents ClienteTableAdapter As VeterinariaDataSetTableAdapters.ClienteTableAdapter
    Friend WithEvents TableAdapterManager As VeterinariaDataSetTableAdapters.TableAdapterManager
    Friend WithEvents CodClienteTextBox As TextBox
    Friend WithEvents NombreCliente As TextBox
    Friend WithEvents ApellidoTextBox As TextBox
    Friend WithEvents CedulaTextBox As TextBox
    Friend WithEvents DireccionTextBox As TextBox
    Friend WithEvents TelefonoTextBox As TextBox
    Friend WithEvents MascotaTableAdapter As VeterinariaDataSetTableAdapters.MascotaTableAdapter
    Friend WithEvents MascotaBindingSource As BindingSource
    Friend WithEvents CodMascotaTextBox As TextBox
    Friend WithEvents NombreMascota As TextBox
    Friend WithEvents IdTipoTextBox As TextBox
    Friend WithEvents RazaTextBox As TextBox
    Friend WithEvents PesoTextBox As TextBox
    Friend WithEvents IdClienteTextBox As TextBox
    Friend WithEvents TipoServicioTextBox As TextBox
    Friend WithEvents GroupBox3 As GroupBox
    Friend WithEvents Button2 As Button
    Friend WithEvents Button1 As Button
    Friend WithEvents BuscarMAscota As Button
    Friend WithEvents BuscarCliente As Button
    Friend WithEvents EliminarMascota As Button
    Friend WithEvents EliminarCliente As Button
    Friend WithEvents MostrarMAscota As Button
    Friend WithEvents Mostrar As Button
    Friend WithEvents ModificarMascota As Button
    Friend WithEvents ModificarCliente As Button
    Friend WithEvents AgregarMascota As Button
    Friend WithEvents AgregarCliente As Button
    Friend WithEvents GroupBox4 As GroupBox
    Friend WithEvents ClienteDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As DataGridViewTextBoxColumn
    Friend WithEvents GroupBox5 As GroupBox
    Friend WithEvents MascotaDataGridView As DataGridView
    Friend WithEvents DataGridViewTextBoxColumn7 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As DataGridViewTextBoxColumn
End Class
