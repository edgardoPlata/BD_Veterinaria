﻿Imports System.Data
Imports System.Data.SqlClient
Imports System.Configuration

Module ConexionMaestra

    Public conexion As New SqlConnection("Server= DESKTOP-BMP4QCV;Database= Veterinaria;User Id= sa;Password= 2001")

    Sub Abrir_Conexion()
        If conexion.State = 0 Then
            conexion.Open()
        End If
    End Sub

    Sub cerrar_conexion()
        If conexion.State = 1 Then
            conexion.Close()
        End If
    End Sub
End Module
